using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

namespace DevAncientNaval.Presentation.Map;
public partial class WorldAmbience
{
    private static readonly Vector2[][] CloudFacets =
    {
        RoundCloud(new Vector2[] { new(-3,-1),new(-1,-1),new(-1,-2),new(1,-2),new(1,-1),new(3,-1),
            new(3,1),new(2,1),new(2,2),new(0,2),new(0,1),new(-2,1),new(-2,0),new(-3,0) }),
        RoundCloud(new Vector2[] { new(-3,-1),new(-2,-1),new(-2,-2),new(0,-2),new(0,-1),new(2,-1),
            new(2,0),new(3,0),new(3,2),new(1,2),new(1,1),new(-1,1),new(-1,2),new(-3,2) }),
        RoundCloud(new Vector2[] { new(-4,-1),new(-2,-1),new(-2,-2),new(1,-2),new(1,-1),new(3,-1),
            new(3,1),new(1,1),new(1,2),new(-1,2),new(-1,1),new(-4,1) })
    };
    private readonly Vector2[][] _cloudTops = CloudFacets.Select(shape => new Vector2[shape.Length]).ToArray();
    private readonly Vector2[] _cloudSide = new Vector2[4];
    internal const float CloudThickness = 16;
    internal const float CloudAltitude = 132;
    internal static IReadOnlyList<Vector2[]> CloudSilhouettes => CloudFacets;
    private static Vector2[] RoundCloud(Vector2[] corners)
    {
        var result = new List<Vector2>();
        for (int i = 0; i < corners.Length; i++)
        {
            var corner = corners[i];
            var a = corner.MoveToward(corners[(i + corners.Length - 1) % corners.Length], .16f);
            var b = corner.MoveToward(corners[(i + 1) % corners.Length], .16f);
            for (int step = 0; step <= 3; step++)
            {
                float t = step / 3f;
                result.Add(a * ((1 - t) * (1 - t)) + corner * (2 * t * (1 - t)) + b * (t * t));
            }
        }
        return result.ToArray();
    }
    private BoardTerrainLayer? _sky;
    public override void _Ready()
    {
        AddChild(_waves);
        AddChild(_treasuryGlow);
        _sky = new BoardTerrainLayer
        {
            Name = "HighClouds",
            ZIndex = 3,
            DrawWorld = DrawSky
        };
        AddChild(_sky);
    }

    private bool VisibleSurface(Vector2 point)
    {
        var cell = BoardView.Projection.WorldToGrid(point);
        return _battle!.Board.Contains(cell) && _battle.Vision.IsVisible(DevAncientNaval.Core.Units.Side.Player, cell);
    }

    private void DrawSky(Node2D canvas)
    {
        DrawClouds(canvas, shadows: false);
        DrawGulls(canvas, shadows: false);
    }

    private void DrawClouds(Node2D canvas, bool shadows)
    {
        if (_battle is null)
            return;
        var bounds = _seaBounds;
        for (int cloud = 0; cloud < 5; cloud++)
        {
            int variant = Math.Abs((_battle.Board.Seed + cloud) % CloudFacets.Length);
            var facet = CloudFacets[variant];
            var top = _cloudTops[variant];
            var footprint = new Vector2(28 + cloud % 3 * 4, 14 + cloud % 2 * 3);
            float thickness = CloudThickness * (.85f + cloud % 3 * .16f);
            float x = Mathf.PosMod(cloud * bounds.Size.X * .27f + _time * 4 + _battle.Board.Seed % 701, bounds.Size.X);
            var center = new Vector2(bounds.Position.X + x, bounds.Position.Y + bounds.Size.Y * (.13f + cloud * .17f));
            if (!_drawBounds.Grow(160).HasPoint(center) || !VisibleSurface(center))
                continue;
            if (shadows)
            {
                canvas.DrawSetTransform(center, 0, footprint);
                canvas.DrawColoredPolygon(facet, new Color(.02f, .08f, .1f, .085f));
            }
            else
            {
                // A single connected square footprint has shaded extruded walls.
                // Faces share their boundaries, avoiding dark overlapping cloud discs.
                canvas.DrawSetTransform(center + new Vector2(-36, -CloudAltitude));
                for (int vertex = 0; vertex < facet.Length; vertex++)
                    top[vertex] = facet[vertex] * footprint + new Vector2(-5, -thickness);
                for (int edge = 0; edge < facet.Length; edge++)
                {
                    int next = (edge + 1) % facet.Length;
                    var a = facet[edge] * footprint;
                    var b = facet[next] * footprint;
                    if ((b - a).Cross(top[next] - a) <= .025f)
                        continue;
                    _cloudSide[0] = a;
                    _cloudSide[1] = b;
                    _cloudSide[2] = top[next];
                    _cloudSide[3] = top[edge];
                    canvas.DrawColoredPolygon(_cloudSide, MathF.Abs(b.X - a.X) > 1
                        ? new Color(.72f, .83f, .82f, .22f)
                        : new Color(.62f, .75f, .76f, .19f));
                }
                canvas.DrawColoredPolygon(top, new Color(.95f, .97f, .91f, .24f));
                canvas.DrawLine(top[4], top[7], new Color(1, 1, .94f, .18f), 1, true);
            }
            canvas.DrawSetTransform(Vector2.Zero);
        }
    }

    private void DrawGulls(Node2D canvas, bool shadows)
    {
        foreach (var gull in _gulls)
        {
            float age = _time - gull.Born;
            var water = GullPosition(gull);
            if (!_drawBounds.HasPoint(water) || !VisibleWater(water))
                continue;
            float fade = Math.Min(1, Math.Min(age, gull.Lifetime - age));
            if (shadows)
            {
                canvas.DrawSetTransform(water, 0, new Vector2(1, .35f));
                canvas.DrawCircle(Vector2.Zero, 5, new Color(.04f, .12f, .17f, .2f * fade));
                canvas.DrawSetTransform(Vector2.Zero);
            }
            else
            {
                var bird = water + new Vector2(0, -38 - MathF.Sin(age * .4f + gull.Phase) * 5);
                SetGullWings(bird, MathF.Sin(age * 4.2f * (gull.Scared ? 1.5f : 1) + gull.Phase) * 2.6f, 7, 3);
                canvas.DrawPolyline(_gullWings, new Color(.95f, .96f, .86f, .85f * fade), 1.8f, true);
            }
        }

        foreach (var dock in _docks)
        {
            var center = dock.Center;
            bool startled = _dockAlarms.TryGetValue(dock.Id, out var alarm) && _time - alarm.Born < 18;
            for (int i = 0; i < 3; i++)
            {
                float phase = (startled ? alarm.Born : _time) * .43f + i * 1.7f + dock.Id;
                var water = center + new Vector2(MathF.Cos(phase) * (25 + i * 4), MathF.Sin(phase) * 14);
                float opacity = 1;
                if (startled)
                {
                    float elapsed = _time - alarm.Born;
                    var away = (water - alarm.Origin).Normalized();
                    if (away == Vector2.Zero) away = Vector2.Right;
                    water += away * elapsed * (20 + i * 2);
                    opacity = Math.Clamp((18 - elapsed) / 2, 0, 1);
                }
                if (!_drawBounds.HasPoint(water) || !VisibleWater(water))
                    continue;
                if (shadows)
                {
                    canvas.DrawSetTransform(water, 0, new Vector2(1, .32f));
                    canvas.DrawCircle(Vector2.Zero, 4, new Color(0, .08f, .1f, .2f * opacity));
                    canvas.DrawSetTransform(Vector2.Zero);
                }
                else
                {
                    var bird = water + new Vector2(0, -37 - i * 4);
                    SetGullWings(bird, MathF.Sin(_time * 4.8f * (startled ? 1.5f : 1) + i) * 2.4f, 6, 2);
                    canvas.DrawPolyline(_gullWings, new Color(new Color("f2f0dc"), opacity), 1.7f, true);
                }
            }
        }
    }
}
