using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DevAncientNaval.Core.AI;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Core.Grid;
using DevAncientNaval.Core.Units;
using DevAncientNaval.Core.World;
using DevAncientNaval.Presentation.Camera;
using DevAncientNaval.Presentation.Input;
using DevAncientNaval.Presentation.Map;
using DevAncientNaval.Presentation.UI;
using Godot;
using Side = DevAncientNaval.Core.Units.Side;

namespace DevAncientNaval.Presentation;
public partial class Main
{
    private BattleState? _presentedBattle;
    private long _presentedVision = -1;
    private readonly List<Vector2> _actionTargetScreens = new(16);
    public void Refresh()
    {
        using var trace = DevAncientNaval.Presentation.Diagnostics.PerformanceTrace.Measure("Main.Refresh");
        bool worldChanged = !ReferenceEquals(_presentedBattle, Battle) || _presentedVision != Battle.Vision.Revision;
        ClearConstruction();
        if (_mapPreview && worldChanged)
        {
            foreach (var tile in Battle.Board.Tiles)
                Battle.Vision.RevealCombat(Side.Player, tile.Position);
            Battle.Vision.Recompute(Battle.Ships, Battle.Round * 2, Battle.Villages);
        }

        if (worldChanged)
        {
            BoardView.InvalidateWorld(force: false);
            Ambience.RefreshVisibility();
            _presentedBattle = Battle;
            _presentedVision = Battle.Vision.Revision;
        }

        var selected = Selected;
        var village = SelectedVillage;
        if (selected is null)
            SelectedShipId = null;
        if (village is null)
            SelectedVillageId = null;
        _previewCell = null;
        Fleet.SelectedId = SelectedShipId;
        BoardView.SelectedShipId = SelectedShipId;
        Hud.ShowTile(Battle, BoardView.Selected);
        BoardView.Reachable = CanCommand && Mode == OrderMode.Build && village?.Owner == Side.Player ? Battle.VillageSpawnCells(village.Id).ToArray() : CanCommand && selected?.Owner == Side.Player ? Mode == OrderMode.Build ? Battle.SpawnCells(selected.Id).ToArray() : Mode == OrderMode.None ? SelectedRoutes()?.Costs.Keys.ToArray() ?? Array.Empty<GridPosition>() : Array.Empty<GridPosition>() : Array.Empty<GridPosition>();
        BoardView.Targets = CanCommand && selected?.Owner == Side.Player && Mode == OrderMode.None ? Battle.TargetCells(selected.Id) : Array.Empty<GridPosition>();
        BoardView.AttackArea = Array.Empty<GridPosition>();
        BoardView.Collection = CanCommand && Mode == OrderMode.None ? Battle.CollectionCells(Side.Player) : Array.Empty<GridPosition>();
        BoardView.DockSites = CanCommand && Mode == OrderMode.None ? Battle.DockCells(Side.Player) : Array.Empty<GridPosition>();
        BoardView.Building = Mode == OrderMode.Build;
        Hud.InstantPaperAnimations = FastChecks;
        Hud.UpdateBattle(Battle, selected, Busy, Mode, village);
        if (CanCommand && _salvoCell is { } target && SelectedShipId == _salvoActorId)
            Hud.ShowSalvoChoice(Battle.CanDoubleSalvo(_salvoActorId, target), Battle.Rules.CounterBetweenSalvoShots);
        else Hud.HideSalvoChoice();
        RefreshOffscreenNavigation();
        PositionActions();
        BoardView.RefreshOverlays();
        Fleet.QueueRedraw();
        RefreshOutcome();
        PresentPendingRewards();
        RefreshTutorials();
    }

    private void PositionActions()
    {
        PositionNavigationMarkers();
        Vector2 Screen(GridPosition p) => GetViewport().GetCanvasTransform() * BoardView.ToGlobal(BoardView.Projection.GridToWorld(p));
        Vector2 TownScreen(Village town) => GetViewport().GetCanvasTransform() * BoardView.ToGlobal(BoardView.VillageWorldAnchor(town));
        Hud.PositionActions(_resourceCell is null ? (Selected is { } ship ? Screen(ship.Position) : SelectedVillage is { } village ? TownScreen(village) : BoardView.Selected is { } inspected ? Screen(inspected) : null) : null,
            (Selected is { } selected ? ShipVisualProfile.ProgressY(selected.Definition.Class) : SelectedVillage is not null ? 34 : 0) * MapCamera.Zoom.Y,
            MapCamera.Zoom.Y);
        _actionTargetScreens.Clear();
        foreach (var attackCell in BoardView.Targets)
            _actionTargetScreens.Add(Screen(attackCell));
        // The ring must also leave neighboring friendly objects selectable.
        // Optical/owned air units use their raised drawing anchor, not the sea
        // tile beneath them. Anonymous radar contacts remain tile points above.
        foreach (var observed in Battle.ObservedShips(Side.Player))
            if (observed.Id != SelectedShipId)
                _actionTargetScreens.Add(Screen(observed.Position) +
                    (observed.IsAirborne ? new Vector2(0, -62) * MapCamera.Zoom : Vector2.Zero));
        foreach (var town in Battle.ObservedVillages(Side.Player))
            if (town.Id != SelectedVillageId)
                _actionTargetScreens.Add(TownScreen(town));
        Hud.SetActionTargetHitExclusions(_actionTargetScreens);
        Hud.PositionResource(_resourceCell is { } cell ? Screen(cell) : null);
        Hud.PositionStories(p => Battle.ObservedVillages(Side.Player).FirstOrDefault(v => v.Position == p) is { } storyTown
            ? TownScreen(storyTown) : Screen(p));
        if (_salvoCell is { } target)
        {
            var targetShip = Battle.ObservedAt(Side.Player, target);
            float offset = targetShip is not null ? ShipVisualProfile.ProgressY(targetShip.Definition.Class)
                : Battle.ObservedVillages(Side.Player).Any(v => v.Position == target) ? 69 : 24;
            Hud.PositionSalvoChoice(Screen(target), offset * MapCamera.Zoom.Y);
        }
    }

    public override void _Process(double delta)
    {
        var transform = GetViewport().GetCanvasTransform();
        var size = GetViewport().GetVisibleRect().Size;
        if (transform == _lastCanvasTransform && size == _lastViewportSize)
            return;
        _lastCanvasTransform = transform;
        _lastViewportSize = size;
        PositionActions();
        // World-space overlay commands are retained; the renderer clips them after a pan.
    }
}

