using DevAncientNaval.Core.Grid;
using DevAncientNaval.Core.Units;
using DevAncientNaval.Core.World;
using DevAncientNaval.Core.Economy;
using DevAncientNaval.Core.Vision;

namespace DevAncientNaval.Core.Battle;
public enum FleetColor
{
    Blue,
    Green,
    Yellow,
    Purple,
    White,
    Red
}

public sealed record SavedBoard(int Width, int Height, int Seed, GridPosition[] Land, SavedMesh? Mesh, WorldKind Kind = WorldKind.Oceans, MapSize? MapSize = null);
public sealed record SavedVillage(int Id, GridPosition Position, Side? Owner, int Level, double Health, int TurnsOwned, bool Fortified, bool Produced, bool Repaired, bool Attacked, string Name = "", bool Port = false, GridPosition? PortCell = null, CityFacility Facility1 = CityFacility.None, CityFacility Facility2 = CityFacility.None, CityFacility ImprovedFacility = CityFacility.None, int UpgradeWorkRemaining = 0, int UpgradeProjectPrice = 0, bool DevelopmentPaused = false);
public sealed record SavedWait(int Target, Side Side, int Ship, GridPosition Position, int Since);
public sealed record SavedHome(int Ship, GridPosition Position);
public sealed record SavedOutcome(int Treasury, TreasuryReward Reward);
/// <summary>Version-one storage contract. Keep names and defaults compatible with released saves.</summary>
public sealed class BattleSave
{
    public int Version { get; set; } = 1;
    public VoyageStatistics Statistics { get; set; } = VoyageStatistics.Empty;
    public SavedBoard Board { get; set; } = null !;
    public BattleRules Rules { get; set; } = null !;
    public SavedShip[] Ships { get; set; } = Array.Empty<SavedShip>();
    public SavedVillage[] Villages { get; set; } = Array.Empty<SavedVillage>();
    public GridPosition[] Fish { get; set; } = Array.Empty<GridPosition>();
    public GridPosition[] Shoals { get; set; } = Array.Empty<GridPosition>();
    public Treasury[] Treasuries { get; set; } = Array.Empty<Treasury>();
    public Whirlpool[] Whirlpools { get; set; } = Array.Empty<Whirlpool>();
    public SavedWait[] CaptureWaits { get; set; } = Array.Empty<SavedWait>();
    public SavedWait[] TreasuryWaits { get; set; } = Array.Empty<SavedWait>();
    public SavedTradeRaid[] TradeRaids { get; set; } = Array.Empty<SavedTradeRaid>();
    public SavedHome[] PirateHomes { get; set; } = Array.Empty<SavedHome>();
    public SavedOutcome[] Outcomes { get; set; } = Array.Empty<SavedOutcome>();
    public IncomeSource[] Income { get; set; } = Array.Empty<IncomeSource>();
    public SavedVision[] Vision { get; set; } = Array.Empty<SavedVision>();
    public int[] Credits { get; set; } = Array.Empty<int>();
    public bool[] EverProduced { get; set; } = Array.Empty<bool>();
    public int NextId { get; set; }
    public int Round { get; set; }
    public int TurnSerial { get; set; }
    public Side ActiveSide { get; set; }
    public Side? Winner { get; set; }
    public bool IsDraw { get; set; }
    public bool GodEye { get; set; }
    public AiDifficulty Difficulty { get; set; } = AiDifficulty.Captain;
    public SavedAiPlan[] AiPlans { get; set; } = Array.Empty<SavedAiPlan>();
    public bool PiratesEnabled { get; set; } = true;
    public bool Creative { get; set; }
    public FleetColor Color { get; set; }
    public Side[] Factions { get; set; } = Array.Empty<Side>();
    public FactionIdentity[] FactionNames { get; set; } = Array.Empty<FactionIdentity>();
    public FactionColor[] FactionColors { get; set; } = Array.Empty<FactionColor>();
    public PendingAward[] PendingAwards { get; set; } = Array.Empty<PendingAward>();
    public NationEncounter[] Encounters { get; set; } = Array.Empty<NationEncounter>();
    public SavedFlagshipSighting[] FlagshipSightings { get; set; } = Array.Empty<SavedFlagshipSighting>();
    public int[] PersonalTurnStarts { get; set; } = Array.Empty<int>();
    public int[] FlagshipKills { get; set; } = Array.Empty<int>();
    public long[] DirectShipKills { get; set; } = Array.Empty<long>();
    public int EventSeed { get; set; }
    public int EventDraws { get; set; }
    public TreasuryReward? LastReward { get; set; }
}

