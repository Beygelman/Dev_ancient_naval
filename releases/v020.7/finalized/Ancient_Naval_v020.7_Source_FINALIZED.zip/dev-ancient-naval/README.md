# Ancient Naval — v020.7 — The Sacred Voyage

A turn-based naval tactics game for Windows, built with Godot 4.7.2 .NET and .NET 8. Explore an organic six-sided world, sustain your people, and defeat the rival Motherships. The interface supports English, Ukrainian and Dutch.

## v020.7 finalized checkpoint — 5 October 2026

The frozen gameplay baseline is commit `b03c5bdc85498f5f5d76f03f4d070adcaa13aa34`, branch `codex/ancient-naval-v020.7`, [PR #6](https://github.com/Beygelman/Dev_ancient_naval/pull/6). Finalization corrects export hygiene, reproducibility and documentation; it adds no mechanics or balance changes. The primary local checkout contains newer v020.8 work and must not be reset to this checkpoint.

**The final native frame gates passed after the final Debug build.** Final player/source packages and their SHA256 manifest belong additively under `releases/v020.7/finalized/`. Extract the complete player folder and keep the PCK and entire runtime beside **Ancient Naval.exe**.

- [Windows player](releases/v020.7/finalized/Ancient_Naval_v020.7_Windows_PLAYER_CLEAN.zip).
- [Source checkpoint](releases/v020.7/finalized/Ancient_Naval_v020.7_Source_FINALIZED.zip).
- [SHA256](releases/v020.7/finalized/SHA256-v020.7-finalized.txt) and [actual artifact validation](releases/v020.7/finalized/FINAL-ARTIFACT-VALIDATION.json).

- [Current audit and verification](docs/V0207_FINALIZATION_REPORT.md), [release procedure](docs/RELEASE-PROCEDURE-v020.7.md), [milestone](docs/MILESTONE-v020.7.md).

The earlier `finalization-candidate/` archives remain separate evidence; their unapproved performance status describes that earlier checkpoint. Original release ZIPs, manifests and historical checkpoints remain unchanged. Player archives contain the executable, PCK, complete runtime and a short player readme. Diagnostics, development documentation, tests, preview commands and PDB files belong outside the player package. The source ZIP retains source, assets, configuration, tests, engineering documentation and verification evidence; it excludes caches and recursive release archives.

## Play

**New game** chooses a fleet color/emblem, 1–4 rivals, Boatswain/Captain/Admiral difficulty, Lake/Bay/Sea/Ocean size and Sea World/Oceans/Continents/Pangaea terrain. **Continue** resumes the last unfinished voyage. Language, hints and interface scale are available in Settings. God's eye changes human visibility only; opponents retain normal observations.

Select an owned object, then a destination, visible target or anonymous radar contact within weapon reach. Ships may pass through friendly occupants; enemy cells block travel and neighboring threats increase cost. Diagonals follow the actual shared-corner mesh and normal terrain restrictions. A second click cycles currently observed occupants sharing a cell. The worn papyrus actions and information cards describe the selected object's current saved rules.

Drag or use WASD/arrows to pan; the wheel zooms the sea. Open modal papers isolate their scrolling/input from the map. Space requests End turn; R repairs the selected eligible object. Projectile salvos commit each deterministic impact after its flight, with a separate counterattack phase. Pellet count and animation speed never multiply damage.

## Current new-voyage balance

These are base definitions in `data/balance.json`, before upgrades, veterancy, condition, terrain and port discounts. Existing voyages keep their embedded rules. Internal serialized names remain stable even where displayed names changed.

| Class | Price, Thors | Base HP | Base damage | Movement, cells | Weapon reach, cells |
|---|---:|---:|---:|---:|---:|
| Mothership | Starting flagship | 15 | 3 | 2 | 2 |
| Brig | 5 | 5 | 3 | 4 | 2 |
| Support Brig | 4 | 5 | 0 | 3 | 0 |
| Galleon | 7 | 10 | 5 | 4 | 2 |
| Kolonel | 12 | 15 | 4 | 3 | 2 |
| Granado | 16 | 5 | 8 | 3 | 5 |
| Fishing dock | 8 | 10 | 0 | 0 | 0 |
| Cannon Tower | 6 | 10 | 3 | 0 | 4 |
| Lighthouse | 6 | 10 | 0 | 0 | 0 |

New voyages start with 8 Thors and base flagship income 2. Towns progress through paid levels costing 5/7/10/15 Thors; their optional fortification costs 8. A level-3 port costs 6, adds 1 income and gives its shipyard a 20% discount. Current active repair restores up to 3 HP; eligible automatic ship/town repair uses 4 HP, and ancient structures use their separately saved policy. Support Brigs collect supplies and build permitted sea infrastructure.

Weighted fleet slots are Mothership 0, Brig/Support Brig 1, Galleon 2, Granado 3 and Kolonel 4; balloons and structures consume none. Dismantling refunds 40% of actual paid construction cost, rounded to whole Thors; free gifts and starting hulls yield zero. Selected diagonal port berths persist through Continue. Trade lanes use the saved navigation policy and maximum direct route length of six transitions.

A balloon crash is a separate staged impact: 2 damage on its cell and eight nearest neighbors, including friendlies. Treasury outcomes are 22% each for ancient gun/currency/ancient balloon/resources and 12% whirlpool. Towns survive at zero HP and require the documented waiting crew before capture. Personal expedition judgement uses persisted direct kills, built strongholds, towns, economy, duration, size and difficulty. Missing optional fields in historical saves retain historical behavior.

## Saved voyages

The single slot is `%APPDATA%/Godot/app_userdata/Ancient Naval/last_battle.json`, with a valid previous checkpoint as `.bak`. New game atomically replaces the voyage and removes its preceding voyage backup after successful writing. Continue preserves generated geometry, rule snapshots, RNG, faction identities, chosen port cells, statistics, waiting crews and camera. Recovery keeps a good backup when the primary is corrupt. Never run diagnostics against this real slot.

## Develop and verify

Open `project.godot` with Godot **4.7.2 .NET**; stop an earlier run with F8 and run with F5. Read [AGENTS.md](AGENTS.md) before edits. Core is independent of Godot; `BattleState` owns gameplay commands. The released renderer is OpenGL Compatibility. Do not infer frame pacing from headless checks.

```powershell
dotnet build Dev_ancient_naval.csproj
$env:ANCIENT_NAVAL_LEGACY_FIXTURES = (Resolve-Path tests/CoreChecks/Fixtures/Historical).Path
dotnet run --project tests/CoreChecks/CoreChecks.csproj --configuration Release
```

Native test examples require explicit disposable save and preference paths:

```powershell
& 'PATH/TO/Godot_v4.7.2-stable_mono_win64.exe' --path . -- --menu-test --save-file=C:/temp/naval-menu.json --ui-settings-file=C:/temp/naval-menu-interface.txt
& tools/Check-ReleaseSmoothness.ps1 -GodotPath 'PATH/TO/Godot_v4.7.2-stable_mono_win64.exe' -ReportDirectory C:/temp/naval-frames
```

Run frame gates serially after the final Debug build, without competing builds or heavy tests. Full source/export/package commands and limits are in the [release procedure](docs/RELEASE-PROCEDURE-v020.7.md). Recorded passes describe this host rather than every player's machine.

## History and next development

The [preserved pre-finalization README](docs/history/README-v0207-pre-finalization.md) contains older release links and historical numbers; use the current balance table and saved rule snapshot for v020.7. [CHANGELOG.md](CHANGELOG.md) and milestone documents retain implementation history. The [beta roadmap](docs/ROADMAP-TO-BETA.md) remains unchanged. Android export/device validation is future work. Reconcile preserved v020.8 work against this checkpoint after verification before continuing that version; no v020.8 feature is backported here.
