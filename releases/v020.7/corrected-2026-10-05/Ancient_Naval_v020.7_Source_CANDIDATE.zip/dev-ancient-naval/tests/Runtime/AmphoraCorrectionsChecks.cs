using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Core.Grid;
using DevAncientNaval.Core.Units;
using DevAncientNaval.Core.World;
using DevAncientNaval.Presentation;
using DevAncientNaval.Presentation.Map;
using DevAncientNaval.Presentation.UI;
using Godot;
using Side = DevAncientNaval.Core.Units.Side;

namespace DevAncientNaval.Tests.Runtime;

/// <summary>Native corrected vessel art, shared class motifs and unchanged health/input contracts.</summary>
public partial class AmphoraCorrectionsChecks : Node
{
    public Main Game { get; set; } = null!;
    private int _checks;
    private static readonly FleetColor[] Nations = { FleetColor.Blue, FleetColor.Purple,
        FleetColor.Yellow, FleetColor.White, FleetColor.Green, FleetColor.Red };
    private void Check(bool good, string message)
    {
        if (!good) throw new InvalidOperationException("Amphora corrections: " + message);
        _checks++;
    }
    private static IEnumerable<Node> Nodes(Node root)
    {
        yield return root;
        foreach (Node child in root.GetChildren()) foreach (Node node in Nodes(child)) yield return node;
    }
    private async Task Frames(int count = 5)
    {
        for (int i = 0; i < count; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
    }
    private static double Area(Vector2[] polygon)
    {
        double twice = 0;
        for (int i = 0; i < polygon.Length; i++) twice += polygon[i].Cross(polygon[(i + 1) % polygon.Length]);
        return Math.Abs(twice) / 2;
    }
    private void ProfilesAndHealth()
    {
        foreach (bool veteran in new[] { false, true })
            for (int stage = 0; stage < 4; stage++)
            {
                Vector2[] profile = ClayAmphoraShape.Profile(stage, veteran);
                Check(profile.Length == profile.Distinct().Count(), "profiles have no duplicate closure vertices");
                int[] triangles = Geometry2D.TriangulatePolygon(profile);
                Check(triangles.Length > 0, "native renderer triangulates intact and damaged clay");
                double coverage = 0;
                for (int i = 0; i < triangles.Length; i += 3)
                    coverage += Math.Abs((profile[triangles[i + 1]] - profile[triangles[i]])
                        .Cross(profile[triangles[i + 2]] - profile[triangles[i]])) / 2;
                Check(Math.Abs(coverage - Area(profile)) < .002, "triangles cover the complete curved silhouette");
            }
        var intact = ClayAmphoraShape.Profile(0);
        float mouth = intact.Where(p => p.Y < -25).Max(p => p.X) - intact.Where(p => p.Y < -25).Min(p => p.X);
        float belly = intact.Max(p => p.X) - intact.Min(p => p.X);
        float neck = intact.Where(p => p.Y is >= -20 and <= -11).Max(p => p.X)
            - intact.Where(p => p.Y is >= -20 and <= -11).Min(p => p.X);
        Check(mouth > 30 && neck < mouth * .6f && belly > mouth,
            "reference has a flared lip, short neck and wider pear-shaped belly");
        Check(ClayAmphoraShape.Profile(0, true).Min(p => p.Y) < intact.Min(p => p.Y) - 10,
            "veteran neck remains longer than the ordinary vessel");
        foreach (var state in new[] { (100d, 0), (75d, 1), (50d, 2), (25d, 3) })
            Check(AmphoraBadgeArt.Stage(state.Item1, 100) == state.Item2, "four health thresholds are unchanged");
        Check(AmphoraBadgeArt.DigitAnchor(new(13, 29)) == new Vector2(13, 33),
            "damage-feedback anchor remains fixed relative to the health badge");
        var animation = new AmphoraHealthAnimation();
        animation.Observe(100, 100, 0);
        animation.Observe(25, 100, .1f);
        var impact = animation.Motion(.14f);
        Check(impact.Stage == 3 && impact.PreviousStage == 0 && !impact.Healing && impact.Shake.Length() > 0,
            "damage still shakes and fractures the same health stages");
        animation.Observe(80, 100, 1);
        var repair = animation.Motion(1.05f);
        Check(repair.PreviousStage == 3 && repair.Stage == 0 && repair.Healing && repair.Shake == Vector2.Zero
            && repair.Restore is > 0 and < 1, "repair rejoins clay without a damage jolt");
        Check(animation.Motion(1.1f).Flash > 0 && animation.Motion(1.5f).Flash > 0,
            "repair retains both glaze flashes");
        Check(!animation.Active(1.9f), "health animation remains bounded");
        Check(NavalGlyphArt.Symbol(ShipClass.Mothership) == ActionSymbol.Mothership
            && NavalGlyphArt.Symbol(null) == ActionSymbol.City && NavalGlyphArt.IsNaval(ActionSymbol.Mothership),
            "floating twin-hull city is distinct from the coastal-town brush motif");
    }
    private async Task Capture(string suffix)
    {
        string? path = OS.GetCmdlineUserArgs().FirstOrDefault(a => a.StartsWith("--capture="))?[10..];
        if (path is null || DisplayServer.GetName() == "headless") return;
        await Frames();
        await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
        Check(GetViewport().GetTexture().GetImage().SavePng(path.Replace(".png", "-" + suffix + ".png")) == Error.Ok,
            "native corrected-art capture " + suffix);
        await Frames(1);
    }
    private Control GalleryRoot(CanvasLayer layer, string caption)
    {
        AddChild(layer);
        var root = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
        layer.AddChild(root);
        root.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
        root.AddChild(new ColorRect { Color = new("233f49"), Size = GetViewport().GetVisibleRect().Size,
            MouseFilter = Control.MouseFilterEnum.Ignore });
        var title = new Label { Text = caption, Position = new(24, 16), MouseFilter = Control.MouseFilterEnum.Ignore };
        title.AddThemeFontSizeOverride("font_size", 23);
        root.AddChild(title);
        return root;
    }
    private async Task Gallery()
    {
        var original = GetWindow().Size;
        GetWindow().Size = new(1280, 720);
        await Frames();
        var layer = new CanvasLayer { Layer = 90 };
        var root = GalleryRoot(layer, "Clay vessels · curled ears · faction glaze");
        ShipClass?[] study = { ShipClass.Mothership, ShipClass.Garrison, ShipClass.Fishing,
            ShipClass.Kolonel, ShipClass.Togus, null };
        float column = GetViewport().GetVisibleRect().Size.X / Nations.Length;
        for (int i = 0; i < Nations.Length; i++)
        {
            var jug = new ReadyActionJug { Position = new(column * (i + .5f) - 56, 82), Size = new(112, 124),
                MouseFilter = Control.MouseFilterEnum.Ignore };
            root.AddChild(jug);
            jug.Update(12 + i, FleetPalette.Color(Nations[i]), Nations[i]);
            for (int stage = 0; stage < 4; stage++)
                root.AddChild(new StudyBadge { Position = new(column * (i + .5f) + 14, 285 + stage * 90),
                    Scale = Vector2.One * 2.6f, Color = FleetPalette.Color(Nations[i]), Kind = study[i],
                    Health = new[] { 100d, 75d, 50d, 25d }[stage], Veteran = i % 2 == 1 });
        }
        await Capture("faction-vessels");
        layer.QueueFree();
        await Frames();
        ShipClass?[] classes = Enum.GetValues<ShipClass>().Select(kind => (ShipClass?)kind).Append(null).ToArray();
        for (int page = 0; page * 2 < classes.Length; page++)
        {
            layer = new CanvasLayer { Layer = 90 };
            root = GalleryRoot(layer, "Every class · six faction glazes · intact / 75% / 50% / 25%");
            for (int row = 0; row < 2 && page * 2 + row < classes.Length; row++)
            {
                ShipClass? kind = classes[page * 2 + row];
                var name = new Label { Text = kind?.ToString() ?? "Coastal town", Position = new(24, 63 + row * 316),
                    MouseFilter = Control.MouseFilterEnum.Ignore };
                root.AddChild(name);
                for (int nation = 0; nation < Nations.Length; nation++)
                    for (int stage = 0; stage < 4; stage++)
                        root.AddChild(new StudyBadge { Position = new(column * (nation + .5f) + 14, 120 + row * 316 + stage * 64),
                            Scale = Vector2.One * 1.8f, Color = FleetPalette.Color(Nations[nation]), Kind = kind,
                            Health = new[] { 100d, 75d, 50d, 25d }[stage], Veteran = nation % 2 == 1 });
            }
            await Capture("all-classes-" + (page + 1));
            layer.QueueFree();
            await Frames();
        }
        GetWindow().Size = original;
        await Frames();
    }
    private BattleState Fixture()
    {
        var town = new GridPosition(8, 7);
        var battle = new BattleState(new GameBoard(20, 20, cell => cell == town ? TerrainType.Land : TerrainType.Water),
            Game.Battle.Rules, new[] { (Side.Player, ShipClass.Mothership, new GridPosition(5, 5)),
                (Side.Player, ShipClass.Garrison, new GridPosition(7, 5)),
                (Side.Player, ShipClass.Fishing, new GridPosition(5, 7)),
                (Side.Enemy, ShipClass.Mothership, new GridPosition(18, 18)) },
            Array.Empty<GridPosition>(), villageSpots: new[] { town });
        var saved = battle.CaptureSnapshot();
        saved.Credits[0] = 100;
        saved.Villages[0] = saved.Villages[0] with { Owner = Side.Player };
        battle = BattleState.LoadJson(BattleState.SerializeSnapshot(saved));
        foreach (var award in battle.PendingAwards.ToArray()) battle.ClaimAward(award.Owner, award.Id);
        return battle;
    }
    private void Click(Vector2 point)
    {
        GetViewport().PushInput(new InputEventMouseMotion { Position = point, GlobalPosition = point }, true);
        foreach (bool down in new[] { true, false })
            GetViewport().PushInput(new InputEventMouseButton { Position = point, GlobalPosition = point,
                ButtonIndex = MouseButton.Left, Pressed = down,
                ButtonMask = down ? MouseButtonMask.Left : (MouseButtonMask)0 }, true);
    }
    private async Task LiveCounter()
    {
        Game.LoadScenario(Fixture());
        Game.Home.Hide();
        Game.FastChecks = true;
        Game.Hud.InstantPaperAnimations = true;
        UiHints.Set(true, false);
        Game.Refresh();
        await Frames();
        var jug = Nodes(Game.Hud).OfType<ReadyActionJug>().Single();
        var end = Nodes(Game.Hud).OfType<EndTurnPaper>().Single();
        Check(jug.IsVisibleInTree() && !jug.IsProcessing(), "ready jug stays visible without per-frame processing");
        Check(jug.Count == Game.Battle.ReadyActions(Side.Player).Count, "printed count retains the exact ready query");
        Check(jug.GetParent() == end.GetParent() && jug.GetIndex() < end.GetIndex(),
            "large vessel is layered behind the end-turn inscription");
        Check(!jug._HasPoint(jug.Size * .5f + new Vector2(0, 52)), "overlapping lower clay cannot steal end-turn input");
        var original = GetWindow().Size;
        float originalScale = UiScale.Value;
        foreach (var window in new[] { new Vector2I(1280, 720), new Vector2I(618, 1400), new Vector2I(800, 520) })
        {
            GetWindow().Size = window;
            foreach (float scale in new[] { .8f, 1.25f })
            {
                UiScale.Set(scale, false);
                Game.Refresh();
                await Frames();
                Check(jug.Size == new Vector2(112, 124), "art is laid out at a fixed content size across UI scales");
                Vector2 point = jug.GetGlobalTransformWithCanvas() * jug.PrintedCountCenter;
                Check(GetViewport().GetVisibleRect().HasPoint(point), "printed counter remains on screen");
                string unchanged = Game.Battle.SaveJson();
                Click(point);
                await Frames();
                Check(Game.Hud.ReadyActionsMenuVisible, "native printed-counter click opens the ready list");
                var ready = Game.Battle.ReadyActions(Side.Player);
                foreach (var item in ready)
                {
                    var button = Nodes(Game.Hud).OfType<Button>().Single(b => b.Name == "SideReady"
                        + (item.ShipClass is null ? "Town" : "Ship") + item.Id);
                    Check(Nodes(button).OfType<ActionGlyph>().Single().Symbol == NavalGlyphArt.Symbol(item.ShipClass),
                        "ready list uses the shared observed object glyph");
                }
                Check(Game.Battle.SaveJson() == unchanged, "art, scale and clicks do not change simulation or rewards");
                await Capture("live-counter-" + window.X + "x" + window.Y + "-" + (int)(scale * 100));
                Game.Hud.CloseReadyActionsMenu();
            }
        }
        UiScale.Set(originalScale, false);
        GetWindow().Size = original;
        Game.Refresh();
        await Frames();
        Check(!Nodes(Game.Fleet).Any(node => node.Name == "HealthAmphorae4"),
            "hidden enemy health/class badge remains absent");
    }
    public override async void _Ready()
    {
        try
        {
            await Frames();
            ProfilesAndHealth();
            await Gallery();
            await LiveCounter();
            GD.Print($"PASS: {_checks} v020.7 corrected amphora, shared brush glyph, health anchor and native input checks.");
            GetTree().Quit();
        }
        catch (Exception error) { GD.PushError(error.ToString()); GetTree().Quit(1); }
    }
    private partial class StudyBadge : Node2D
    {
        internal Color Color { get; init; }
        internal ShipClass? Kind { get; init; }
        internal double Health { get; init; }
        internal bool Veteran { get; init; }
        public override void _Draw() => AmphoraBadgeArt.Draw(this, Vector2.Zero, Health, 100, Color, Kind,
            AmphoraMotion.Still(Health, 100), Veteran);
    }
}
