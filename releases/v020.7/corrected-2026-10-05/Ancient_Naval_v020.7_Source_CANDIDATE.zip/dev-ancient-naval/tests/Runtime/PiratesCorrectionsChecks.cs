using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Core.Units;
using DevAncientNaval.Core.World;
using DevAncientNaval.Presentation;
using DevAncientNaval.Presentation.UI;
using Godot;
using Side = DevAncientNaval.Core.Units.Side;

namespace DevAncientNaval.Tests.Runtime;

/// <summary>The real setup input and single Continue slot preserve both pirate policies.</summary>
public partial class PiratesCorrectionsChecks : Node
{
    public Main Game { get; set; } = null!;
    private int _checks;
    private void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException("Pirate corrections: " + message);
        _checks++;
    }
    private static IEnumerable<Node> Nodes(Node parent)
    {
        yield return parent;
        foreach (Node child in parent.GetChildren())
            foreach (Node node in Nodes(child)) yield return node;
    }
    private Button Button(Node surface, string name) => Nodes(surface).OfType<Button>().Single(b => b.Name == name);
    private Button Button(string name) => Button(Game.Home, name);
    private async Task Frames(int count = 3)
    {
        for (int i = 0; i < count; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
    }
    private async Task WaitFor(Func<bool> ready, string phase, ulong milliseconds = 5000)
    {
        ulong deadline = Time.GetTicksMsec() + milliseconds;
        while (!ready())
        {
            if (Time.GetTicksMsec() >= deadline)
                throw new InvalidOperationException("Pirate corrections timed out: " + phase);
            await Frames(1);
        }
    }
    private void Click(Control control)
    {
        var point = control.GetGlobalTransformWithCanvas() * (control.Size * .5f);
        GetViewport().PushInput(new InputEventMouseMotion { Position = point, GlobalPosition = point }, true);
        foreach (bool down in new[] { true, false })
            GetViewport().PushInput(new InputEventMouseButton { Position = point, GlobalPosition = point,
                ButtonIndex = MouseButton.Left, Pressed = down,
                ButtonMask = down ? MouseButtonMask.Left : (MouseButtonMask)0 }, true);
    }
    private async Task Reveal(Button button)
    {
        await Frames();
        Nodes(Game.Home).OfType<ScrollContainer>().Single(n => n.Name == "VoyageSetupScroll").EnsureControlVisible(button);
        await Frames();
        Check(button.IsVisibleInTree(), "setup choice remains visible: " + button.Name);
        var point = button.GetGlobalTransformWithCanvas() * (button.Size * .5f);
        var viewport = GetViewport().GetVisibleRect();
        Check(viewport.HasPoint(point), "native setup hit point stays inside viewport: " + button.Name);
    }
    private async Task Capture(string suffix)
    {
        string? path = OS.GetCmdlineUserArgs().FirstOrDefault(a => a.StartsWith("--capture="))?[10..];
        if (path is null || DisplayServer.GetName() == "headless") return;
        await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
        Check(GetViewport().GetTexture().GetImage().SavePng(path.Replace(".png", "-" + suffix + ".png")) == Error.Ok,
            "capture " + suffix);
        await Frames(1);
    }
    private void CheckMessage(string source, string locale)
    {
        string translated = Language.Translate(source);
        Check(locale == "en" || translated != source, "catalog translates " + locale + ": " + source);
        Check(!translated.Contains("[[plural:") && !Regex.IsMatch(translated, @"\{\d+\}"),
            "formatted message resolves every placeholder and plural marker");
    }
    private void CheckMenuLanguage(string locale)
    {
        foreach (string name in new[] { "HomeNewGame", "HomeSettings", "HomeExit", "CancelColor", "IncludePirates" })
        {
            var button = Button(name);
            Check(button.AutoTranslateMode != Control.AutoTranslateModeEnum.Disabled
                && button.Tr(button.Text).ToString() == Language.Translate(button.Text),
                "native menu translation bridge " + locale + ": " + name);
            CheckMessage(button.Text, locale);
        }
        var start = Button("StartBattle");
        string expected = Language.Translate("Embark with the {0} nation")
            .Replace("{0}", NationIdentity.Name(Game.Home.SelectedColor));
        Check(start.Text == expected, "dynamic Embark choice updates with the active language");
        foreach (string source in new[] {
            "Mothership · level 3", "Dismantle ship", "Dismantle ship · return 4 Thors",
            "Each enemy ship sunk fills one cell.", "Click to capture the town.", "Click to collect relics.",
            "Upgrade town · 7 Thors", "Install radar · 2 Thors", "Radar installed · range 4",
            "Repair: up to +3 HP · R", "Sail to an available tile", "Build a combat ship",
            "Your voyage begins. Explore, collect resources and protect your Mothership.",
            "You preserved your people.\nThe ship of new hope sails on.",
            "Pirate bays and patrols appear at the start. Disabling them keeps neutral towns and resources." })
            CheckMessage(source, locale);
        foreach (var choice in Enum.GetValues<UpgradeChoice>())
        {
            CheckMessage(MysticUpgradeButton.Title(choice), locale);
            CheckMessage(UpgradeDescriptions.Description(choice, Game.Battle.Rules), locale);
        }
        var checkbox = Button("IncludePirates");
        Check(checkbox.Tr(checkbox.TooltipText).ToString() == Language.Translate(checkbox.TooltipText),
            "native checkbox tooltip translates in " + locale);
        foreach (string prefix in new[] { "Difficulty", "MapSize", "World" })
            foreach (var choice in Nodes(Game.Home).OfType<Button>().Where(b => b.Name.ToString().StartsWith(prefix)))
            {
                var caption = Nodes(choice).OfType<Label>().Single();
                CheckMessage(caption.Text, locale);
                Check(caption.Tr(caption.Text).ToString() == Language.Translate(caption.Text),
                    "native choice caption translates in " + locale + ": " + choice.Name);
                if (prefix == "Difficulty") CheckMessage(choice.TooltipText, locale);
            }
        foreach (var choice in Nodes(Game.Home).OfType<Button>().Where(b => b.Name.ToString().StartsWith("OpponentCount")))
            CheckMessage(choice.TooltipText, locale);

        // A blocked command must translate all of its facts, not just its object
        // name and final error. These composed tooltips previously bypassed the
        // complete-sentence templates once a price/reason suffix was attached.
        foreach (string source in new[] {
            "Port · 6 Thors · Level 3 · +1 income · 20% shipyard discount · linked sea lanes · Not enough Thors.",
            "Outpost · 8 Thors · 25% resistance · automatic guns from level 2, range 2, damage 2; counter +1 · sight 5 · Not enough Thors.",
            "Fishing Dock · +1 resources, +2 income · 8 Thors",
            "Fishing Dock · +1 resources, +2 income · 8 Thors · not enough Thors",
            "Collect resource shoal · +1 resource · 3 Thors · not enough Thors",
            "Support Brig · 4 Thors · This Mothership has already built a ship this turn." })
        {
            CheckMessage(source, locale);
            string translated = Language.Translate(source);
            if (locale == "en") Check(translated == source, "English choices preserve original facts");
            else Check(new[] { "income", "resistance", "sight ", "shipyard discount", "linked sea lanes", "not enough Thors", "resources" }
                .All(fragment => !translated.Contains(fragment, StringComparison.Ordinal)),
                "blocked choice has no untranslated English clauses in " + locale + ": " + source);
            Check(Regex.Matches(source, @"\d+").Select(m => m.Value).OrderBy(n => n)
                .SequenceEqual(Regex.Matches(translated, @"\d+").Select(m => m.Value).OrderBy(n => n)),
                "translated choices retain every numeric fact");
        }
    }
    private async Task StartVoyage(bool includePirates)
    {
        var checkbox = Button("IncludePirates");
        await Reveal(checkbox);
        if (Game.Home.IncludePirates != includePirates) { Click(checkbox); await Frames(); }
        Check(Game.Home.IncludePirates == includePirates, "native setup commits chosen policy before Embark");
        var previousOrder = Game.CurrentOrder;
        var start = Button("StartBattle"); await Reveal(start); Click(start);
        await WaitFor(() => Game.CurrentOrder != previousOrder || Game.Home.Transitioning || !Game.Home.IsOpen,
            "native Embark acceptance");
        var order = Game.CurrentOrder;
        await WaitFor(() => order.IsCompleted, "new voyage generation and disposable save", 60000);
        await order; await Frames();
        Check(!Game.Home.IsOpen && Game.Battle.PiratesEnabled == includePirates,
            "real generated voyage receives the on/off policy");
        Check(Game.Battle.Board.MapSize == MapSize.Lake, "selected area reaches the generated voyage");
        Check(includePirates ? Game.Battle.OwnShips(Side.Pirates).Any() && Game.Battle.Villages.Any(v => v.Owner == Side.Pirates)
            : Game.Battle.Ships.All(s => s.Owner != Side.Pirates) && Game.Battle.Villages.All(v => v.Owner != Side.Pirates),
            "generated pirates and bays follow the actual checkbox");
        Check(Game.Saves.Exists && Game.Saves.Read().Battle.SaveJson() == Game.Battle.SaveJson(),
            "new game writes the exact policy to the disposable Continue slot");
        Game.VoyageWelcome.Close();
        Game.Tutorial.Clear();
    }
    private async Task ContinueVoyage(bool includePirates)
    {
        string saved = Game.Battle.SaveJson();
        Game.ShowHome(); await Frames();
        var keep = Button("HomeContinue");
        Check(keep.IsVisibleInTree() && !keep.Disabled, "Continue exposes the latest unfinished voyage");
        // The next-voyage checkbox must not overwrite the stored policy on Continue.
        Game.Home.ShowColors(); await Reveal(Button("IncludePirates"));
        if (Game.Home.IncludePirates == includePirates) { Click(Button("IncludePirates")); await Frames(); }
        await Reveal(Button("CancelColor")); Click(Button("CancelColor")); await Frames();
        var before = Game.CurrentOrder; Click(keep);
        await WaitFor(() => Game.CurrentOrder != before || !Game.Home.IsOpen, "native Continue acceptance");
        var order = Game.CurrentOrder;
        await WaitFor(() => order.IsCompleted, "native Continue restore");
        await order; await Frames();
        Check(Game.Battle.PiratesEnabled == includePirates && Game.Battle.SaveJson() == saved,
            "Continue preserves saved pirates instead of applying next-voyage choices");
    }
    public override async void _Ready()
    {
        try
        {
            Check(OS.GetCmdlineUserArgs().Any(a => a.StartsWith("--save-file=")), "explicit disposable save is required");
            await Frames(); Game.FastChecks = true; Game.ShowHome(); Game.Home.ShowColors();
            var checkbox = (CheckBox)Button("IncludePirates");
            Check(Game.Home.IncludePirates, "pirates remain enabled by default");
            foreach (float scale in new[] { .8f, 1f, 1.25f })
            {
                UiScale.Set(scale, persist: false);
                foreach (string locale in new[] { "en", "uk", "nl" })
                {
                    Language.Set(locale, persist: false); await Reveal(checkbox);
                    CheckMenuLanguage(locale);
                    Check(checkbox.GetGlobalTransformWithCanvas().Scale.IsEqualApprox(new Vector2(scale, scale)),
                        "checkbox uses native scale and matching input in " + locale);
                    bool before = Game.Home.IncludePirates;
                    Click(checkbox); await Frames();
                    Check(Game.Home.IncludePirates != before, "native checkbox responds in " + locale);
                    if (scale == 1f) await Capture("setup-" + locale);
                }
            }
            UiScale.Set(1f, persist: false); Language.Set("en", persist: false);
            await Reveal(Button("MapSizeLake")); Click(Button("MapSizeLake")); await Frames();
            await StartVoyage(false);
            await ContinueVoyage(false);
            Game.Hud.InstantPaperAnimations = true;
            Game.Hud.SetMenuVisible(true); await Frames();
            foreach (string locale in new[] { "uk", "nl" })
            {
                Language.Set(locale, persist: false); await Frames();
                foreach (string name in new[] { "NewGame", "GameSettings", "CloseMenu", "MainMenu", "ExitGame" })
                {
                    var action = Button(Game.Hud, name);
                    CheckMessage(action.Text, locale);
                    Check(action.Tr(action.Text).ToString() == Language.Translate(action.Text),
                        "live game menu translation bridge: " + name);
                }
                foreach (string name in new[] { "GodEye", "Creative" })
                    CheckMessage(Button(Game.Hud, name).TooltipText, locale);
            }
            Game.Hud.SetMenuVisible(false);
            await WaitFor(() => !Game.Hud.MenuVisible, "game menu closing");
            Language.Set("en", persist: false); Game.ShowHome(); Game.Home.ShowColors(); await Frames();
            await StartVoyage(true);
            Check(!File.Exists(Game.Saves.Path + ".bak"), "new voyage removes the previous voyage backup");
            await ContinueVoyage(true);
            GD.Print($"PASS: {_checks} v020.7 native pirate setup, translations, scales and Continue checks.");
            GetTree().Quit();
        }
        catch (Exception error) { GD.PushError(error.ToString()); GetTree().Quit(1); }
    }
}
