using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Core.Grid;
using DevAncientNaval.Core.Units;
using DevAncientNaval.Core.World;
using DevAncientNaval.Presentation;
using DevAncientNaval.Presentation.UI;
using Godot;
using Side = DevAncientNaval.Core.Units.Side;

namespace DevAncientNaval.Tests.Runtime;

/// <summary>Corrected v020.7 command routing, world labels and claim acknowledgement.</summary>
public partial class CorrectionUiChecks : Node
{
    public Main Game { get; set; } = null!;
    private int _checks;
    private static readonly GridPosition Town = new(8, 7), HiddenTown = new(18, 7), Relic = new(12, 7);

    private void Check(bool value, string message)
    {
        if (!value) throw new InvalidOperationException("Correction UI: " + message);
        _checks++;
    }

    private static IEnumerable<Node> Nodes(Node node)
    {
        yield return node;
        foreach (var child in node.GetChildren()) foreach (var descendant in Nodes(child)) yield return descendant;
    }

    private async Task Frames(int count = 3)
    {
        for (int i = 0; i < count; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
    }

    private async Task Until(Func<bool> condition, string name, double seconds = 3)
    {
        var elapsed = Stopwatch.StartNew();
        while (!condition() && elapsed.Elapsed.TotalSeconds < seconds) await Frames(1);
        Check(condition(), name);
    }

    private void Tap(Vector2 point, bool touch = false)
    {
        GetViewport().PushInput(new InputEventMouseMotion { Position = point, GlobalPosition = point }, true);
        foreach (bool down in new[] { true, false })
            if (touch)
                GetViewport().PushInput(new InputEventScreenTouch { Index = 3, Position = point, Pressed = down }, true);
            else
                GetViewport().PushInput(new InputEventMouseButton { Position = point, GlobalPosition = point,
                    ButtonIndex = MouseButton.Left, Pressed = down,
                    ButtonMask = down ? MouseButtonMask.Left : (MouseButtonMask)0 }, true);
    }

    private void Tap(SectorButton command, bool touch = false) => Tap(command.GetGlobalTransformWithCanvas() * command.IconCenter, touch);
    private void Tap(Control control, bool touch = false) => Tap(control.GetGlobalTransformWithCanvas() * (control.Size / 2), touch);

    private async Task Capture(string suffix)
    {
        string? path = OS.GetCmdlineUserArgs().FirstOrDefault(a => a.StartsWith("--capture="))?[10..];
        if (path is null || DisplayServer.GetName() == "headless") return;
        await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
        int extension = path.LastIndexOf('.');
        path = extension < 0 ? path + "-" + suffix + ".png" : path[..extension] + "-" + suffix + path[extension..];
        Check(GetViewport().GetTexture().GetImage().SavePng(path) == Error.Ok, "native capture " + suffix);
        await Frames(1);
    }

    private BattleState Fixture(bool readyStories = false)
    {
        var battle = new BattleState(new GameBoard(24, 20,
                p => p == Town || p == HiddenTown ? TerrainType.Land : TerrainType.Water, seed: 731),
            Game.Battle.Rules, new[] {
                (Side.Player, ShipClass.Mothership, new GridPosition(4, 4)),
                (Side.Player, ShipClass.Garrison, new GridPosition(7, 7)),
                (Side.Player, ShipClass.Garrison, new GridPosition(11, 7)),
                (Side.Enemy, ShipClass.Mothership, new GridPosition(22, 18)) },
            Array.Empty<GridPosition>(), villageSpots: new[] { Town, HiddenTown });
        var saved = battle.CaptureSnapshot();
        saved.Credits[0] = 1000;
        saved.Ships[0].Level = 5;
        saved.Ships[0].Health = Game.Battle.Rules.Get(ShipClass.Mothership).MaxHealth
            + 4 * Game.Battle.Rules.Get(ShipClass.Mothership).HealthPerLevel;
        saved.Villages = saved.Villages.Select(v => v.Position != Town ? v : readyStories
            ? v with { Health = 0 } : v with { Level = 3, Health = 15, Owner = Side.Player }).ToArray();
        if (readyStories)
        {
            int id = saved.NextId++;
            saved.Treasuries = new[] { new Treasury(id, Relic) };
            saved.Outcomes = new[] { new SavedOutcome(id, TreasuryReward.Currency) };
        }
        battle = BattleState.LoadJson(BattleState.SerializeSnapshot(saved));
        if (readyStories)
        {
            Check(battle.Move(Side.Player, 3, Relic).Success, "relic crew reaches its actual tile");
            Check(battle.EndTurn(Side.Player).Success && battle.EndTurn(Side.Enemy).Success, "claim crews wait one owner turn");
        }
        battle.SetGodEye(true);
        return battle;
    }

    private void Load(BattleState battle, bool animate = false)
    {
        Game.Home.Hide();
        Game.Tutorial.Clear();
        Game.FastChecks = !animate;
        Game.LoadScenario(battle);
        Game.MapCamera.Position = Game.BoardView.Projection.GridToWorld(Town) + new Vector2(0, -35);
        Game.MapCamera.Zoom = Vector2.One;
        Game.MapCamera.ForceUpdateScroll();
        Game.Refresh();
    }

    private SectorButton[] Commands(RadialPapyrus fan) => fan.GetChildren().OfType<SectorButton>().Where(c => c.IsVisibleInTree()).ToArray();

    private void CheckRightmost(RadialPapyrus fan)
    {
        var commands = Commands(fan);
        var info = commands.Single(c => c.Name == "ActionInformation" || c.Name == "ProbeInformation");
        var infoPoint = info.GetGlobalTransformWithCanvas() * info.IconCenter;
        Check(commands.All(c => (c.GetGlobalTransformWithCanvas() * c.IconCenter).X <= infoPoint.X + .01f),
            "Info stays geometrically rightmost with " + commands.Length + " real actions");
        Check(fan.ActionCount == commands.Length, "parchment geometry contains only real visible commands");
    }

    private async Task NativeCommandFans()
    {
        foreach (float scale in new[] { .8f, 1.25f })
        {
            UiScale.Set(scale, persist: false);
            Load(Fixture());
            Game.SelectCell(new(4, 4));
            await Frames();
            var fan = Nodes(Game.Hud).OfType<RadialPapyrus>().Single(n => n.Name == "ActionPapyrus");
            await Until(() => fan.Reveal == 1, "selected Mothership command paper finishes its native unfolding");
            Tap(Nodes(fan).OfType<SectorButton>().Single(n => n.Name == "ActionBuild"));
            await Until(() => fan.Reveal == 1, "opened shipyard finishes its native unfolding");
            Check(Commands(fan).Length >= 7 && Commands(fan).Any(n => n.Name == "BuildGarrison"),
                "actual shipyard, rather than the original command menu, exercises the crowded fan");
            CheckRightmost(fan);
            var info = Commands(fan).Single(n => n.Name == "ActionInformation");
            Tap(info, touch: scale > 1);
            await Frames();
            Check(Game.Hud.InformationVisible, "mouse/touch reaches Info in the crowded shipyard");
            Tap(Nodes(Game.Hud).OfType<Button>().Single(n => n.Name == "CloseInformation"));
            await Until(() => !Game.Hud.InformationVisible, "native close returns from counsel to the town commands");
            Game.SelectCell(Town);
            await Until(() => fan.Reveal == 1, "selected town command paper finishes its native unfolding");
            CheckRightmost(fan);
            var upgrade = Commands(fan).Single(n => n.Name == "ActionVillageUpgrade");
            Check(Math.Abs(upgrade.CenterAngle - Mathf.Pi / 2) < .001f, "town upgrade remains centered without a spacer");
            var town = Game.Battle.Villages.Single(v => v.Position == Town);
            int before = town.Level;
            await Capture("town-fan-" + (int)(scale * 100));
            Tap(upgrade, touch: scale < 1);
            await Game.CurrentOrder;
            Check(town.Level == before + 1, "centered town command routes native input to the actual upgrade");
        }
        UiScale.Set(1, persist: false);
    }

    private async Task ManyCommandInputs()
    {
        Load(Fixture());
        Game.CancelOrder();
        foreach (int count in new[] { 7, 8, 12 })
        {
            var layer = new CanvasLayer { Layer = 80, Scale = Vector2.One * .8f };
            AddChild(layer);
            var fan = new RadialPapyrus { Size = new(248, 248), MouseFilter = Control.MouseFilterEnum.Ignore,
                Position = GetViewport().GetVisibleRect().Size / 1.6f - SectorButton.Center };
            layer.AddChild(fan);
            var hits = new int[count];
            var commands = Enumerable.Range(0, count).Select(i =>
            {
                var command = new SectorButton { Name = i == 0 ? "ProbeInformation" : "ProbeCommand" + i,
                    Size = new(248, 248), MouseFilter = Control.MouseFilterEnum.Stop };
                foreach (string state in new[] { "normal", "hover", "pressed", "disabled", "focus" })
                    command.AddThemeStyleboxOverride(state, new StyleBoxEmpty());
                command.Pressed += () => hits[i]++;
                var glyph = new ActionGlyph { Symbol = i == 0 ? ActionSymbol.Information : ActionSymbol.Repair,
                    Size = new(32, 32), MouseFilter = Control.MouseFilterEnum.Ignore };
                command.AddChild(glyph);
                var badge = new Label(); command.AddChild(badge); command.AttachInk(glyph, badge);
                fan.AddChild(command);
                return command;
            }).ToArray();
            fan.Configure(commands, false, count == 12 ? commands[count / 2] : null);
            await Frames();
            CheckRightmost(fan);
            for (int i = 0; i < count; i++) { Tap(commands[i], touch: i % 2 == 0); await Frames(1); }
            Check(hits.All(h => h == 1), "all crowded real wedges route one mouse/touch command each");
            var target = commands[0].IconCenter;
            foreach (var command in commands) command.SetWorldTargetHitExclusions(new[] { target }, 15);
            fan.RefreshInkBounds();
            CheckRightmost(fan);
            int tapped = 0;
            void OnMapTap(Vector2 _) => tapped++;
            Game.MapInput.Tapped += OnMapTap;
            Tap(fan.GetGlobalTransformWithCanvas() * target);
            Game.MapInput.Tapped -= OnMapTap;
            Check(tapped == 1 && hits.All(h => h == 1), "target hole preserves map input without executing a parchment command");
            fan.Configure(commands, true);
            layer.Hide();
            Check(!fan.IsProcessing(), "hidden unfolding command paper stops processing");
            layer.QueueFree();
            await Frames();
        }
    }

    private async Task CounsellingAndWorldLabels()
    {
        Load(Fixture());
        await Frames();
        var battle = Game.Battle;
        var brig = battle.Find(2)!;
        var page = AncientLore.Ship(battle, brig);
        Check(page.PlainText.Contains("0/3 ships sunk") && !page.PlainText.Contains("+25%")
            && !page.PlainText.Contains("after three kills"), "unearned veteran rewards are absent while current progress remains");
        Check(!AncientLore.Village(battle, battle.Villages.Single(v => v.Position == Town)).Sections
            .SelectMany(s => s.Rows).Any(r => r.Label == "Next level"), "town counsel does not advertise future upgrade prices");
        var saved = battle.CaptureSnapshot();
        saved.Ships[1].IsVeteran = true; saved.Ships[1].Kills = 3;
        var veteran = BattleState.LoadJson(BattleState.SerializeSnapshot(saved));
        Check(AncientLore.Ship(veteran, veteran.Find(2)!).Sections.Single(s => s.Title == "Installed improvements")
            .Rows.Any(r => r.Label == "Veteran"), "earned veteran improvements remain documented");
        var interfaces = Nodes(Game.Fleet).OfType<Node2D>().Where(n => n.Name.ToString().StartsWith("TownInterface")).ToArray();
        // Include the real foreground projectile/effect layer and every retained ship badge.
        int highestForeground = Nodes(Game.Fleet).OfType<Node2D>().Where(n => n.Name == "ShellsAndFeedback"
            || n.Name.ToString().StartsWith("HealthAmphorae")).Select(n => n.ZIndex).DefaultIfEmpty(8).Max();
        Check(interfaces.Length == 2 && interfaces.All(n => n.ZIndex > highestForeground), "city labels draw above ship badges and combat effects");
        battle.SetGodEye(false); Game.Refresh(); await Frames();
        int hiddenId = battle.Villages.Single(v => v.Position == HiddenTown).Id;
        Check(!Nodes(Game.Fleet).OfType<Node2D>().Single(n => n.Name == "TownInterface" + hiddenId).IsVisibleInTree(),
            "raising city labels does not reveal a previously unknown town");
    }

    private async Task StoryCaptionsAndCommit()
    {
        var battle = Fixture(readyStories: true);
        Load(battle, animate: true);
        UiHints.Set(true, false);
        var claim = Game.Hud.ClaimPapyrus;
        var treasury = Game.Hud.TreasuryPapyrus;
        await Until(() => claim.Reveal == 1 && treasury.Reveal == 1, "both ready illustrations finish unfolding");
        foreach (string locale in new[] { "en", "uk", "nl" })
            foreach (float scale in new[] { .8f, 1.25f })
            {
                Language.Set(locale, persist: false); UiScale.Set(scale, persist: false); await Frames();
                foreach (var paper in new[] { claim, treasury })
                {
                    var caption = paper.GetNode<Label>("ActionGuidance");
                    float paperCenter = (paper.GetGlobalTransformWithCanvas() * (paper.Size / 2)).X;
                    float captionCenter = (caption.GetGlobalTransformWithCanvas() * (caption.Size / 2)).X;
                    Check(Math.Abs(paperCenter - captionCenter) < .1f && caption.Size.X == paper.Size.X,
                        "caption remains centered under its own " + paper.Name + " in " + locale + " at " + scale);
                    Check(caption.GetGlobalRect().End.Y * UiScale.Value <= GetViewport().GetVisibleRect().Size.Y + 1,
                        "caption remains inside the scaled viewport");
                }
            }
        Language.Set("en", persist: false); UiScale.Set(1, persist: false); await Frames();
        await Capture("ready-captions");
        var town = battle.Villages.Single(v => v.Position == Town);
        Tap(claim, touch: true);
        var order = Game.CurrentOrder;
        await Until(() => claim.FoldProgress > 0 || claim.ConsumptionProgress > 0, "claim begins its fold phase");
        Check(claim.FoldProgress < 1 && claim.Reveal < 1 && claim.ConsumptionProgress == 0 && town.Owner is null,
            "paper folds inward before fire or ownership changes");
        Tap(claim); Check(ReferenceEquals(order, Game.CurrentOrder), "folding paper cannot enqueue another claim");
        await Capture("claim-fold");
        await Until(() => claim.ConsumptionProgress > 0 || order.IsCompleted, "folded paper starts its burn phase");
        Check(!order.IsCompleted && claim.Reveal < .05f && town.Owner is null, "burn follows a completed fold and still precedes capture");
        await Capture("claim-burn");
        await Until(() => order.IsCompleted, "claim acknowledgement completes without a stranded command");
        await order;
        Check(town.Owner == Side.Player && battle.Find(2)!.IsExhausted && !claim.IsProcessing(),
            "one finished ceremony commits capture and exhausts the actual crew");

        int credits = battle.Credits(Side.Player);
        Tap(treasury);
        order = Game.CurrentOrder;
        Check(Game.Busy && treasury.IsConsuming && battle.Treasuries.Count == 1, "treasury keeps its Core reward pending while folding");
        treasury.SetOnScreen(false);
        await Until(() => order.IsCompleted, "hidden consuming paper releases its cosmetic acknowledgement");
        await order;
        Check(!treasury.IsProcessing() && !treasury.IsConsuming && battle.Treasuries.Count == 0
            && battle.Credits(Side.Player) == credits + battle.Rules.Treasury.CurrencyReward,
            "skipped hidden cosmetics award the actual discovery exactly once");
        var totals = battle.Statistics;
        await Game.LootTreasury(3);
        Check(battle.Statistics == totals, "a completed hidden discovery cannot pay twice");

        var oldBattle = Fixture(readyStories: true); Load(oldBattle, animate: true);
        await Until(() => claim.Reveal == 1, "replacement scenario has a ready claim");
        Tap(claim); order = Game.CurrentOrder;
        var replacement = Fixture();
        Load(replacement);
        await Until(() => order.IsCompleted, "replacing a voyage safely resolves its old cosmetic wait");
        await order;
        Check(oldBattle.Villages.Single(v => v.Position == Town).Owner is null
            && replacement.Villages.Single(v => v.Position == Town).Level == 3 && !Game.Busy,
            "an interrupted old claim cannot mutate either voyage or lock commands");

        var canceledBattle = Fixture(readyStories: true); Load(canceledBattle, animate: true);
        await Until(() => claim.Reveal == 1, "removed-paper scenario has a ready claim");
        Tap(claim); order = Game.CurrentOrder;
        Node paperParent = claim.GetParent();
        paperParent.RemoveChild(claim);
        await Until(() => order.IsCompleted, "removing a consuming paper cancels its acknowledgement safely");
        await order;
        Check(canceledBattle.Villages.Single(v => v.Position == Town).Owner is null && !Game.Busy,
            "canceling an active claim frees input without committing ownership");
        paperParent.AddChild(claim);
        Load(Fixture());
        UiHints.Set(false, false);
    }

    private async Task PaperLifecycle()
    {
        var layer = new CanvasLayer { Layer = 90 };
        AddChild(layer);
        var paper = new ActionPapyrus
        {
            ArtworkPath = "res://assets/ui/harbor-claim-0.20.png",
            Position = new(100, 100)
        };
        layer.AddChild(paper);
        paper.SetReady(true);
        var consuming = paper.ConsumeAsync();
        Check(ReferenceEquals(consuming, paper.ConsumeAsync()), "repeat cosmetic consumption shares its single acknowledgement");
        paper._Process(.1);
        Check(!consuming.IsCompleted && paper.FoldProgress > 0 && paper.FoldProgress < 1
            && paper.ConsumptionProgress == 0, "visible paper retains the full fold interval before fire");
        layer.Hide();
        Check(consuming.IsCompletedSuccessfully && !paper.IsProcessing(), "a hidden parent finishes only the cosmetic wait and stops processing");
        layer.Show(); paper.SetOnScreen(false); paper.SetReady(true);
        var hidden = paper.ConsumeAsync();
        Check(hidden.IsCompletedSuccessfully && !paper.IsVisibleInTree() && !paper.IsProcessing(),
            "a paper already outside the viewport cannot force itself visible or strand its acknowledgement");
        layer.QueueFree();
        await Frames();
    }

    public override async void _Ready()
    {
        try
        {
            await Frames();
            await NativeCommandFans();
            await ManyCommandInputs();
            await CounsellingAndWorldLabels();
            await StoryCaptionsAndCommit();
            await PaperLifecycle();
            GD.Print($"PASS: {_checks} corrected v020.7 native command/caption/claim/visibility checks ({DisplayServer.GetName()}).");
            GetTree().Quit();
        }
        catch (Exception error)
        {
            GD.PushError(error.ToString());
            GetTree().Quit(1);
        }
    }
}
