using System.Text.Json;
using System.Text.Json.Nodes;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Core.Economy;
using DevAncientNaval.Core.Grid;
using DevAncientNaval.Core.Units;
using DevAncientNaval.Core.World;

internal static class PiratesCorrectionsChecks
{
    internal static int Run(BattleRules rules)
    {
        int checks = 0;
        void Check(bool condition, string message)
        {
            if (!condition) throw new Exception("v020.7 pirate choice: " + message);
            checks++;
        }
        void Reject(Action action, string message)
        {
            try { action(); }
            catch (ArgumentException) { checks++; return; }
            throw new Exception("v020.7 pirate choice: " + message);
        }
        BattleState Restore(BattleSave save) => BattleState.LoadJson(BattleState.SerializeSnapshot(save));
        var land = new HashSet<GridPosition>();
        var villages = new List<GridPosition>();
        for (int y = 12; y <= 36; y += 8)
        for (int x = 12; x <= 36; x += 8)
        {
            villages.Add(new(x, y));
            land.Add(new(x, y));
            land.Add(new(x + 1, y));
        }
        BattleState Fixture(GameBoard board, bool? includePirates = null)
        {
            var setup = new[] { (Side.Player, ShipClass.Mothership, new GridPosition(3, 3)),
                (Side.Enemy, ShipClass.Mothership, new GridPosition(44, 44)),
                (Side.Player, ShipClass.Garrison, new GridPosition(5, 3)) };
            return includePirates is { } enabled
                ? new(board, rules, setup, resourceSeed: board.Seed, villageSpots: villages,
                    seaEvents: true, generatedSettlements: true, piratesEnabled: enabled)
                : new(board, rules, setup, resourceSeed: board.Seed, villageSpots: villages,
                    seaEvents: true, generatedSettlements: true);
        }

        foreach (var size in Enum.GetValues<MapSize>())
        {
            var board = new GameBoard(48, 48, p => land.Contains(p) ? TerrainType.Land : TerrainType.Water,
                seed: 20731 + (int)size, mapSize: size);
            var historicalDefault = Fixture(board);
            var enabled = Fixture(board, true);
            var disabled = Fixture(board, false);
            Check(enabled.PiratesEnabled && historicalDefault.SaveJson() == enabled.SaveJson(),
                size + " explicit enabled matches the historical default exactly");
            Check(enabled.Villages.Count(v => v.Owner == Side.Pirates) == (int)size + 2
                && enabled.OwnShips(Side.Pirates).Count() == enabled.Factions.Count,
                size + " preserves released bay quota and one patrol per territory");
            foreach (var difficulty in Enum.GetValues<AiDifficulty>())
            {
                string before = JsonSerializer.Serialize(enabled.CaptureSnapshot().Ships);
                string towns = JsonSerializer.Serialize(enabled.CaptureSnapshot().Villages);
                enabled.SetDifficulty(difficulty);
                Check(JsonSerializer.Serialize(enabled.CaptureSnapshot().Ships) == before
                    && JsonSerializer.Serialize(enabled.CaptureSnapshot().Villages) == towns,
                    "difficulty does not change v020.7 pirate population or statistics");
            }
            Check(!disabled.PiratesEnabled && disabled.OwnShips(Side.Pirates).Count() == 0
                && disabled.Villages.All(v => v.Owner is null)
                && disabled.CaptureSnapshot().PirateHomes.Length == 0
                && disabled.CaptureSnapshot().Income.All(i => i.Owner != Side.Pirates),
                size + " disabled choice has no pirate hulls, bays, homes or income");
            Check(enabled.Villages.Select(v => v.Position).SequenceEqual(disabled.Villages.Select(v => v.Position))
                && enabled.FishSpots.SequenceEqual(disabled.FishSpots)
                && enabled.Shoals.SequenceEqual(disabled.Shoals)
                && enabled.TreasuryRuins.SequenceEqual(disabled.TreasuryRuins),
                size + " disabled pirates retain settlement sites and all sea resources");
            Check(enabled.CaptureSnapshot().EventSeed == disabled.CaptureSnapshot().EventSeed
                && enabled.CaptureSnapshot().EventDraws == disabled.CaptureSnapshot().EventDraws,
                "pirate choice does not consume treasury randomness");
            foreach (var battle in new[] { enabled, disabled })
                Check(BattleState.LoadJson(battle.SaveJson()).SaveJson() == battle.SaveJson(),
                    "on/off preference and full saved state resume exactly");

            var legacyJson = JsonNode.Parse(enabled.SaveJson())!.AsObject();
            legacyJson.Remove("PiratesEnabled");
            Check(BattleState.LoadJson(legacyJson.ToJsonString()).SaveJson() == enabled.SaveJson(),
                "absent legacy preference defaults to true without altering pirates or random state");
            var noPiratesLegacy = JsonNode.Parse(disabled.SaveJson())!.AsObject();
            noPiratesLegacy.Remove("PiratesEnabled");
            var restoredLegacy = BattleState.LoadJson(noPiratesLegacy.ToJsonString());
            Check(restoredLegacy.PiratesEnabled && !restoredLegacy.OwnShips(Side.Pirates).Any()
                && JsonSerializer.Serialize(restoredLegacy.CaptureSnapshot().Ships)
                    == JsonSerializer.Serialize(disabled.CaptureSnapshot().Ships),
                "missing preference never regenerates pirates into an existing save");

            // Mature a plunder order in a disposable snapshot, then compare the
            // actual reward stream both before/after Continue and across policies.
            BattleState ReadyTreasury(BattleState battle)
            {
                var saved = battle.CaptureSnapshot();
                var treasury = saved.Treasuries.First();
                var crew = saved.Ships.Single(s => s.Owner == Side.Player && s.Kind == ShipClass.Garrison);
                crew.Position = treasury.Position;
                saved.TurnSerial = 1;
                saved.TreasuryWaits = new[] { new SavedWait(treasury.Id, Side.Player, crew.Id, treasury.Position, 0) };
                return Restore(saved);
            }
            var armed = ReadyTreasury(enabled);
            var peaceful = ReadyTreasury(disabled);
            var resumed = BattleState.LoadJson(peaceful.SaveJson());
            foreach (var battle in new[] { armed, peaceful, resumed })
            {
                int crew = battle.OwnShips(Side.Player).Single(s => s.Definition.Class == ShipClass.Garrison).Id;
                Check(battle.LootTreasury(Side.Player, crew).Success, "real ready treasury command succeeds");
                Check(!battle.LootTreasury(Side.Player, crew).Success, "plunder remains exact-once");
            }
            Check(peaceful.SaveJson() == resumed.SaveJson() && peaceful.LastTreasuryReward == armed.LastTreasuryReward
                && peaceful.CaptureSnapshot().EventDraws == armed.CaptureSnapshot().EventDraws,
                "pirate-free Continue and enabled policy share the unchanged next discovery draw");

            var frozenLevels = disabled.Villages.Select(v => v.Level).ToArray();
            for (int turn = 0; turn < 10; turn++)
            {
                Check(disabled.ActiveSide != Side.Pirates, "disabled pirates never receive a turn");
                Check(disabled.EndTurn(disabled.ActiveSide).Success, "pirate-free voyage advances normally");
            }
            Check(disabled.Villages.Select(v => v.Level).SequenceEqual(frozenLevels),
                "neutral former pirate locations do not grow as pirate bays");

            var invalid = enabled.CaptureSnapshot(); invalid.PiratesEnabled = false;
            Reject(() => Restore(invalid), "contradictory pirate objects are rejected instead of pruned");
            invalid = disabled.CaptureSnapshot(); invalid.ActiveSide = Side.Pirates;
            Reject(() => Restore(invalid), "disabled pirate active turn is rejected");
            invalid = disabled.CaptureSnapshot(); invalid.Winner = Side.Pirates;
            Reject(() => Restore(invalid), "disabled pirate winner is rejected");
            invalid = disabled.CaptureSnapshot();
            invalid.PirateHomes = new[] { new SavedHome(invalid.Ships[0].Id, invalid.Ships[0].Position) };
            Reject(() => Restore(invalid), "disabled pirate patrol homes are rejected");
            invalid = disabled.CaptureSnapshot();
            invalid.Villages[0] = invalid.Villages[0] with { Owner = Side.Pirates };
            Reject(() => Restore(invalid), "disabled pirate-owned settlement is rejected");
            invalid = disabled.CaptureSnapshot();
            invalid.Income = invalid.Income.Append(new IncomeSource("pirate-test", Side.Pirates, 1)).ToArray();
            Reject(() => Restore(invalid), "disabled pirate income is rejected");
            Reject(() => new BattleState(board, rules, new[] {
                (Side.Player, ShipClass.Mothership, new GridPosition(3, 3)),
                (Side.Enemy, ShipClass.Mothership, new GridPosition(44, 44)),
                (Side.Pirates, ShipClass.PirateSchooner, new GridPosition(9, 9)) }, piratesEnabled: false),
                "explicit disabled deployment cannot inject a pirate");
        }

        foreach (var kind in Enum.GetValues<WorldKind>())
        {
            var board = ArchipelagoGenerator.Create(205, 1, kind, MapSize.Lake);
            var enabled = SkirmishSetup.Create(board, rules, 1);
            var disabled = SkirmishSetup.Create(board, rules, 1, piratesEnabled: false);
            Check(ReferenceEquals(enabled.Board, disabled.Board) && disabled.Villages.Count == 6
                && disabled.OwnShips(Side.Pirates).Count() == 0 && disabled.Villages.All(v => v.Owner is null),
                kind + " actual organic setup applies the choice without changing mesh or fair towns");
            Check(enabled.FishSpots.SequenceEqual(disabled.FishSpots)
                && enabled.TreasuryRuins.SequenceEqual(disabled.TreasuryRuins),
                kind + " real setup preserves resources and treasury locations");
            var order = disabled.Prepare(b => b.EndTurn(Side.Player));
            Check(order.Result.Success && !disabled.PiratesEnabled, "prepared command preserves the optional setting");
            order.Finish(); order.Finish();
            Check(!disabled.PiratesEnabled && Restore(disabled.CaptureSnapshot()).SaveJson() == disabled.SaveJson(),
                "finishing a staged command twice neither re-enables pirates nor changes saved policy");
        }
        return checks;
    }
}
