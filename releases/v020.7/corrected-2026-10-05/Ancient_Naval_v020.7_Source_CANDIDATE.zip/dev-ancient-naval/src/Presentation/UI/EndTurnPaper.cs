using System;
using System.Threading.Tasks;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Presentation.Map;
using Godot;

namespace DevAncientNaval.Presentation.UI;

/// <summary>Left-unrolled paper stamps and rolls back into its fixed right-hand spindle.</summary>
internal partial class EndTurnPaper : Button
{
    private float _stamp = 1, _unroll = 1;
    private bool _humanTurn = true, _opening, _folding;
    private Label _caption = null!;
    private TaskCompletionSource? _completion;
    internal float StampProgress => _stamp;
    internal float UnrollProgress => _unroll;
    internal Color NationInk { get; set; } = PaintedVoyageChoice.Burgundy;
    public override void _Ready()
    {
        CustomMinimumSize = new(188, 54);
        FocusMode = FocusModeEnum.None;
        ClipContents = true;
        foreach (string state in new[] { "normal", "hover", "pressed", "disabled", "focus" })
            AddThemeStyleboxOverride(state, new StyleBoxEmpty { ContentMarginLeft = 12, ContentMarginRight = 30 });
        AddThemeFontSizeOverride("font_size", 17);
        AddThemeColorOverride("font_color", new Color(PapyrusStyle.Ink, 0));
        AddThemeColorOverride("font_hover_color", new Color(PapyrusStyle.Ink, 0));
        AddThemeColorOverride("font_pressed_color", new Color(PapyrusStyle.Ink, 0));
        AddThemeColorOverride("font_disabled_color", new Color(PapyrusStyle.Ink, 0));
        _caption = new Label { Name = "EndTurnCaption", Text = Text,
            HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center,
            MouseFilter = MouseFilterEnum.Ignore };
        _caption.AddThemeFontSizeOverride("font_size", 17);
        _caption.AddThemeColorOverride("font_color", PapyrusStyle.Ink);
        AddChild(_caption);
        _caption.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
        _caption.OffsetRight = -22;
        MouseEntered += QueueRedraw;
        MouseExited += QueueRedraw;
        Resized += QueueRedraw;
        SetProcess(false);
    }
    internal void SetHumanTurn(bool active, bool instant)
    {
        if (_humanTurn == active) return;
        _humanTurn = active;
        if (!active)
        {
            Hide();
            return;
        }
        _stamp = 1;
        _unroll = instant ? 1 : 0;
        _opening = !instant;
        Show();
        SetProcess(_opening);
        QueueRedraw();
    }
    internal Task StampAsync(bool instant)
    {
        if (_completion is not null) return _completion.Task;
        _opening = false;
        _folding = false;
        _stamp = instant ? 1 : 0;
        _unroll = 1;
        QueueRedraw();
        if (instant) return Task.CompletedTask;
        _completion = new TaskCompletionSource();
        SetProcess(true);
        return _completion.Task;
    }
    internal Task FoldAsync(bool instant)
    {
        if (_completion is not null) return _completion.Task;
        _opening = false;
        _folding = true;
        if (instant)
        {
            _unroll = 0;
            QueueRedraw();
            return Task.CompletedTask;
        }
        _completion = new TaskCompletionSource();
        SetProcess(true);
        return _completion.Task;
    }
    public override void _Process(double delta)
    {
        if (_opening)
        {
            _unroll = Math.Min(1, _unroll + (float)delta / .35f);
            if (_unroll >= 1) _opening = false;
        }
        else if (_completion is not null)
        {
            if (_folding) _unroll = Math.Max(0, _unroll - (float)delta / .32f);
            else _stamp = Math.Min(1, _stamp + (float)delta / .28f);
        }
        _caption.Modulate = new Color(1, 1, 1, Math.Clamp((_unroll - .25f) / .75f, 0, 1));
        QueueRedraw();
        if (_opening || _completion is not null && (_folding ? _unroll > 0 : _stamp < 1)) return;
        SetProcess(false);
        var completion = _completion;
        _completion = null;
        completion?.TrySetResult();
    }
    public override void _Draw()
    {
        float eased = _unroll * _unroll * (3 - 2 * _unroll);
        float spindleX = Size.X - 22;
        float left = spindleX * (1 - eased);
        var paper = PapyrusStyle.Paper.Lightened(IsHovered() ? .05f : 0);
        var rect = new Rect2(left, 5, Math.Max(1, spindleX - left + 10), Size.Y - 10);
        DrawStyleBox(PapyrusStyle.Panel(), rect);
        DrawTextureRect(PapyrusGrain.Texture, rect, true, new Color(1, 1, 1, .62f));
        var roll = new Rect2(spindleX, 0, 20, Size.Y);
        DrawRect(roll, paper.Darkened(.08f));
        DrawLine(roll.Position, new(roll.Position.X, roll.End.Y), PapyrusStyle.Bronze, 2, true);
        DrawLine(roll.Position + new Vector2(4, 0), new(roll.Position.X + 4, roll.End.Y), paper.Lightened(.14f), 3, true);
        DrawArc(new(Size.X - 12, 5), 9, Mathf.Pi, Mathf.Tau, 14, PapyrusStyle.Bronze, 1, true);
        DrawArc(new(Size.X - 12, Size.Y - 5), 9, 0, Mathf.Pi, 14, PapyrusStyle.Bronze, 1, true);
        if (_completion is not null && _unroll > .65f)
            HandStampArt.Draw(this, Size * .5f, _stamp, NationInk);
    }
    public override void _ExitTree() => _completion?.TrySetCanceled();
}

internal partial class ReadyActionJug : Button
{
    private static readonly Vector2 ArtScale = new(1.90f, 1.75f);
    private static readonly Vector2[] Shadow = Ellipse(new(3, 34), new(26, 5));
    internal int Count { get; private set; }
    internal Vector2 PrintedCountCenter => Size * .5f + new Vector2(2, 8);
    private Color _clay;
    private FleetColor _nation;

    internal void Update(int count, Color clay, FleetColor nation)
    {
        if (Count == count && _clay == clay && _nation == nation) return;
        Count = count;
        _clay = clay;
        _nation = nation;
        QueueRedraw();
    }

    public override void _Ready()
    {
        FocusMode = FocusModeEnum.None;
        foreach (string state in new[] { "normal", "hover", "pressed", "disabled", "focus" })
            AddThemeStyleboxOverride(state, new StyleBoxEmpty());
        MouseEntered += QueueRedraw;
        MouseExited += QueueRedraw;
        Resized += QueueRedraw;
        SetProcess(false);
    }

    public override bool _HasPoint(Vector2 point)
    {
        var p = (point - Size * .5f).Rotated(-.12f) / ArtScale;
        // The lower clay overlaps the end-turn inscription visually but does not steal it.
        return p.Y < 21 && p.Y > -35 && (p / new Vector2(29, 35)).LengthSquared() < 1.15f;
    }

    public override void _Draw()
    {
        DrawSetTransform(Size * .5f, .12f, ArtScale);
        DrawColoredPolygon(Shadow, new Color(.025f, .045f, .045f, .29f));
        var clay = _clay.Darkened(IsHovered() ? .06f : .13f);
        ClayAmphoraShape.Draw(this, clay, turned: true);
        var ink = new Color(PapyrusStyle.Paper, .85f);
        DrawBand(-6, ink);
        DrawBand(21, ink);
        for (int motif = -1; motif <= 1; motif++) DrawMotif(new(motif * 8.1f, -5), ink);
        DrawLine(new(-16, 19), new(15, 19), new Color(ink, .60f), 1.1f, true);
        DrawLine(new(-11, 27), new(10, 27), new Color(ink, .56f), 1.2f, true);
        string text = Count.ToString();
        const int fontSize = 23;
        float width = ThemeDB.FallbackFont.GetStringSize(text, fontSize: fontSize).X;
        var baseline = new Vector2(-width / 2 + 1, 19);
        DrawString(ThemeDB.FallbackFont, baseline + new Vector2(.7f, .6f), text,
            fontSize: fontSize, modulate: new Color(clay.Darkened(.40f), .70f));
        DrawString(ThemeDB.FallbackFont, baseline, text, fontSize: fontSize,
            modulate: new Color(_nation is FleetColor.White or FleetColor.Yellow ? PapyrusStyle.Ink : PapyrusStyle.Paper, .98f));
        DrawSetTransform(Vector2.Zero);
    }

    private void DrawBand(float y, Color ink)
    {
        Vector2 P(float x, float row)
        {
            float halfWidth = row < 0 ? Math.Max(7, 21 + row * .85f)
                : row > 19 ? Math.Max(9, 21 - (row - 19) * 1.3f) : 20;
            return new(x * halfWidth / 19, row);
        }
        DrawLine(P(-19, y), P(18, y), new Color(ink, .64f), 1.1f, true);
        for (int i = 0; i < 7; i++)
        {
            float x = -18 + i * 5;
            DrawPolyline(new[] { P(x, y + 2), P(x + 3, y + 2),
                P(x + 3, y + 4), P(x + 1, y + 4), P(x + 1, y + 6) },
                new Color(ink, .72f), .65f, true);
        }
    }

    private void DrawMotif(Vector2 c, Color ink)
    {
        switch (_nation)
        {
            case FleetColor.Blue:
                DrawArc(c, 2.2f, 0, Mathf.Tau, 14, ink, .8f, true);
                for (int i = 0; i < 8; i++)
                {
                    var d = Vector2.FromAngle(i * Mathf.Tau / 8);
                    DrawLine(c + d * 3.4f, c + d * 4.5f, ink, .65f, true);
                }
                break;
            case FleetColor.Green:
                DrawLine(c + new Vector2(0, 4), c + new Vector2(0, -4), ink, .9f, true);
                for (int i = 0; i < 3; i++)
                {
                    float y = 1 - i * 2;
                    DrawLine(c + new Vector2(0, y), c + new Vector2(-3, y - 2), ink, .7f, true);
                    DrawLine(c + new Vector2(0, y), c + new Vector2(3, y - 2), ink, .7f, true);
                }
                break;
            case FleetColor.White:
                DrawLine(c + new Vector2(-2, 4), c + new Vector2(-2, -4), ink, 1.2f, true);
                DrawLine(c + new Vector2(-3, -4), c + new Vector2(0, -4), ink, .8f, true);
                DrawArc(c + new Vector2(0, -2), 2.2f, -Mathf.Pi / 2, Mathf.Pi / 2, 9, ink, 1, true);
                DrawLine(c, c + new Vector2(3, 4), ink, 1.1f, true);
                break;
            case FleetColor.Yellow:
                for (int i = -1; i <= 1; i++)
                    DrawArc(c + new Vector2(i * 1.9f, 1), 2.3f, Mathf.Pi, Mathf.Tau, 10, ink, .8f, true);
                Diamond(c + new Vector2(0, -2.5f), 2, ink);
                break;
            case FleetColor.Purple:
                DrawPolyline(new[] { c + new Vector2(-3, 3), c + new Vector2(0, -4),
                    c + new Vector2(3, 3), c + new Vector2(-3, 3) }, ink, .9f, true);
                Diamond(c, 2, ink);
                break;
            default:
                Diamond(c, 4, ink);
                DrawLine(c + new Vector2(0, -4), c + new Vector2(0, 4), ink, .7f, true);
                break;
        }
    }

    private void Diamond(Vector2 c, float h, Color ink) => DrawPolyline(new[] {
        c + new Vector2(0, -h), c + new Vector2(h * .55f, 0), c + new Vector2(0, h),
        c + new Vector2(-h * .55f, 0), c + new Vector2(0, -h) }, ink, .75f, true);

    private static Vector2[] Ellipse(Vector2 center, Vector2 radius)
    {
        var points = new Vector2[32];
        for (int i = 0; i < points.Length; i++)
            points[i] = center + Vector2.FromAngle(i * Mathf.Tau / 32) * radius;
        return points;
    }

}
