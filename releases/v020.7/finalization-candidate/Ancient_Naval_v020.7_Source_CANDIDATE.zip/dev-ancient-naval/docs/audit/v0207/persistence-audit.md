# v020.7 save, RNG and staged-command audit

4 October 2026. Read-only static review of `b03c5bdc85498f5f5d76f03f4d070adcaa13aa34` in `C:/Users/User/Documents/Codex/2026-09-29/x20/work/v0207-finalization`. Attached guide revision 4.0 was read completely. No source, historical release, personal save or setting was changed. No build or runtime check was executed by this audit agent; the integrating agent owns execution and final results.

## Contract found

- `BattleSnapshot.cs`, `SavedShip.cs`: battle and session formats remain version 1; internal enum names are preserved. Rules, mesh vertices/faces/boundary, exploration, factions/colors/names, statistics, event seed/draw count, treasury outcomes/waits, ship action flags/trade streak/paid construction receipt and town port cell are serialized.
- `BattleSave.cs`: load validates envelope and rule groups before board/entity restoration. It restores saved mesh rather than regenerating it, clears trade-network caches, preserves existing entity identity during presentation frames, restores the embedded rules and replays the seeded event stream by its saved draw count.
- `BattleRules.cs`, `SpecialWeaponRules.cs`, `BattleSnapshot.cs`: absent v020.7 weighted capacity, diagonal berth, refund, crash damage, receipt, port cell and direct-kill fields have historical-compatible defaults. `Rules0207Checks` explicitly tests omitted fields. Earlier optional fields are also covered by `DataDrivenRulesScenarios`, `Refinement021Checks`, `Rules0203Checks`, `Rules0205Checks` and other compatibility suites.
- `BattleSaveValidation.cs`, `MeshSave.cs`, `VisionSave.cs`, rule validators: collections, enum values, roster consistency, references, geometry indices, nullable nested records and counters are checked before their indexed restoration. `PersistenceChecks` includes malformed nested collection/reference/mesh cases and detached snapshot concurrency/alias checks.
- `SaveStore.cs`: a flushed temporary file atomically replaces the single primary slot; recovery preserves the valid backup when the primary is known invalid, including a first write without a preceding read. A successful new voyage replaces the slot and then removes the preceding voyage's backup. `SaveRecoveryChecks` tests primary corruption, nested corruption, consecutive recovery, healthy rotation, rejected camera values and inability to resurrect the old voyage after New Game.

## Exact-once command boundary

`PresentedCommand.Prepare` evaluates the command on an isolated aggregate and captures deterministic phase snapshots. The live facade blocks competing commands and `CaptureSnapshot`/`SaveJson` while `PendingPresentation` exists. `Impact(key)` ignores repeated keys and `Finish()` is idempotent; finalization applies the complete deterministic state and releases the pending command. Presentation invokes these phase commits, not a second damage calculation. Counterattacks have their own phase and no recursive reply.

`PresentedCombatScenarios` covers unchanged live HP/actions during flight, command/save locks, duplicate impact, staged versus immediate final snapshot equivalence, entity identity, veterancy at impact, flagship/follower destruction ordering and exact repeated completion. `Rules0207Checks` adds separate balloon gun/fall boundaries, friendly crash damage, repeat impact/finish/scuttle protection and persisted direct-kill evidence. `PresentedImpactChecks` and `Animation0207Checks` add native animation sequencing and hidden-target/crash checks.

`MainCommands` finishes pending presentation in its final path before autosave; `MainSession.ExitSession` finishes a pending order before saving and exiting. Fast/skipped presentation uses the same final command snapshot. These are static findings, not a claim that interruption paths were exercised in this run.

## Determinism and information boundaries

The live gameplay stream is private to Core `SeaEvents`: all reward/patrol draws increment `EventDraws`, and saved unresolved reward choices persist to prevent retry rerolls. Cosmetic world names, faction colors, terrain art, salvos, ambient populations and merchant traffic use independent seeded streams. Generation uses deterministic board seeds; presentation cannot access the event RNG.

Existing checks compare generated geometry, exact save round trips, treasury reward results before/after load, custom weighted rewards and read-only previews. God's eye persistence/real-memory isolation and radar anonymity are covered in the existing Core/runtime suites. Runtime crash effects gate victim damage labels/effects on recorded visibility.

No compatibility or exact-once defect requiring a v020.7 gameplay edit was established by this review. A dedicated repeated pirate-patrol command sequence across resume was not found; persistence of its RNG is statically present and other seeded reward replay is tested. This is an additional future regression opportunity, not evidence of a current bug.

## Historical fixtures and reproducibility gap

Two existing pre-refactor fixture files were located and read/hashed without modification. They are dated 30 September 2026 and match the historical fixture naming contract; `docs/MILESTONE-0.14.1.md` records two actual pre-refactor 0.14 session saves in prior verification. They are outside the repository and were not found inside the historical source ZIP inventory, so an unconfigured clean checkout does **not** automatically run those real-fixture cases.

| File | SHA256 |
|---|---|
| `C:/Users/User/Documents/Codex/2026-09-29/x20/work/refactor-persistence/baseline-menu-save.json` | `d926dc9f543e4e4267d483c17c5a3f35dd8e3b9f5d85e9b4f68bdcf73a1c8669` |
| `C:/Users/User/Documents/Codex/2026-09-29/x20/work/refactor-persistence/baseline-menu-preview.json` | `eaee7d9b8b62ff1fadd836d3b8b29ecc1b2afe16ad3c94017dc195fdf81d53dd` |

Set `ANCIENT_NAVAL_LEGACY_FIXTURES` to that directory when the integrating agent runs `dotnet run --project tests/CoreChecks/CoreChecks.csproj --configuration Release`. `PersistenceChecks` then requires at least two `baseline-menu-*.json`, loads each session's battle and checks stable resaving/organic geometry. Preserve byte-identical copies and their hashes in final source/evidence material to make that invocation reproducible without personal workspace dependencies; never substitute a real user's current slot.

For native recovery, run the existing `--menu-test` with an explicit disposable `--save-file=` in a test directory. It invokes `SaveRecoveryChecks` there and creates uniquely named recovery files. The integrating agent must report the actual assertions/logs and distinguish this static audit from the executed compatibility and recovery checks.
