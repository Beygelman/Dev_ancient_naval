# Independent v020.7 release review

4 October 2026. Independent review of the isolated `v0207-finalization` worktree against `b03c5bdc85498f5f5d76f03f4d070adcaa13aa34`. Attached `AGENTS.md` revision 4.0 and `V0207_FINALIZATION.md` were read completely. The initial review was read-only; the integrating agent later approved the narrow capture-harness and displayed-version corrections described below. This reviewer did not build, export, run the game or touch personal saves/settings. Execution results belong to the integrating agent.

## Source boundary

The reconciliation evidence distinguishes a marker-free v020.7 baseline from intentional uncommitted v020.8 changes in the canonical project. Cached `origin/main` still contains 1,482 conflict-marker lines; primary committed HEAD and working source do not. Thus isolation at the verified v020.7 commit is justified, and the primary v020.8 tree must remain intact. At the first review, `git diff b03c5bd -- src data scenes tests` was empty. The subsequent changes to `BattleChecks`/`SeaChecks` were reviewed below; simulation, gameplay data and presentation art remain unchanged. The sole production correction identified later updates displayed footer version metadata.

## Reviewed release controls

- Active Windows preset retains v020.7/0.20.7 metadata, has a new scratch export path, disables debug symbols and script content, and excludes release/documentation/test/tool/work/local-cache folders.
- `Export-FinalizedWindows.ps1` requires a fresh output outside the project, validates the frozen version and relevant preset settings, passes paths as process arguments, retains export logs/exit code and audits the produced PCK. It deliberately avoids the console launcher.
- `Verify-FinalizedRelease.ps1` inspects ZIP paths and the inner PCK directory rather than trusting exterior cleanup. Its v2/v3/v4 layout was compared with the versioned [Godot 4.7.2 pack loader](https://raw.githubusercontent.com/godotengine/godot/4.7.2-stable/core/io/file_access_pack.cpp) and [flag definitions](https://raw.githubusercontent.com/godotengine/godot/4.7.2-stable/core/io/file_access_pack.h).
- Player names are limited to executable, PCK, player readme and complete standard runtime folder. PDBs and development directories are forbidden. Runtime-reference verification compares every non-PDB exporter runtime file byte-for-byte; it should always be supplied by the packaging workflow.
- Disposable `--save-file` also isolates language/tutorial persistence. Explicit `--ui-settings-file` isolates scale/hint persistence. The existing smoothness gate supplies both, remains serial and retains its unchanged thresholds.
- Static navigation inspection found command-local navigation snapshots, stateful trade streaks and centralized movement-preview invalidation. No new defect requiring a gameplay edit was established.

## Findings communicated to integration

1. **Do not use legacy `Sync-Release.ps1` for corrected v020.7 delivery.** Although archive copies are immutable, that helper rewrites `releases/SHA256-v020.7.txt` and `releases/latest.json`. Additive finalization artifact names and a separate manifest preserve historical metadata and avoid falsely advertising v020.7 as the latest work over v020.8.
2. **Reject PCK removal/delta and duplicate entries — corrected during review.** The first verifier revision counted removal entries toward required resource presence and did not reject duplicate archive/resource paths. The integrating agent now rejects nonzero per-resource flags and duplicate resource/player/source member names. This concerns validation of full release packs, not gameplay.
3. **Bound reproducibility claims.** Sorted ZIP entries and fixed timestamps can make packaging byte-reproducible for identical inputs; this does not by itself prove that separate Godot/.NET export invocations generate identical binaries. Record engine/SDK/export inputs and say exactly which repeated comparison was performed.

## Packaging helper review

`Package-FinalizedRelease.ps1` was subsequently reviewed. It uses Git-tracked source/config/assets/tests/tools/docs plus explicitly reviewed new files, rejects unreviewed untracked source, excludes generated/private/archive content, records actual working-tree byte hashes and carries developer evidence separately. All tracked required assets are retained; the unused original sound-library distribution is excluded. All non-PDB runtime files are copied intact and hash-compared with the exporter output. ZIP creation has fixed metadata, ordinal order and exclusive output semantics. The source ZIP verifier independently checks the per-file byte inventory.

One concrete invocation defect was found and reported: PowerShell unwraps a one-element function output to a scalar string, so `(Read-GitLines @('rev-parse', 'HEAD'))[0]` selects a character. The corresponding commit-resolution call then rejects a valid full commit. Wrap the call in `@(Read-GitLines ...)[0]` or preserve the array in the helper. This was reproduced with a pure read-only PowerShell expression; no release/build/test process was run by this reviewer.

The generic evidence filename filter also rejects a harmless report named `save-audit.md`; rename that report or include it through explicitly reviewed source documentation. Actual disposable save fixtures should enter only through the reviewed test-fixture source inventory, with their provenance/hash documentation.

Final release execution, repeat-package hashes, source extraction/build, native startup and performance must still be confirmed by the integrating agent. No build/native/compatibility/performance pass is claimed in this document.

## Runtime harness reconciliation

The later `tests/Runtime/BattleChecks.cs` and `SeaChecks.cs` edits replace obsolete timing assumptions with bounded waits for actual unfold/fold/acknowledgement phases. They retain native modal input blocking, assert the actual five flagship sector commands, retain the selected-object ledger screen anchor and verify treasury crew exhaustion/consumed-command exact-once behavior. The reward helper accepts already-present legitimate modals through native pointer input before attempting a world claim; it does not bypass the input guard or grant a reward directly. These are test harness reconciliation and stronger current-invariant checks, not gameplay backports or relaxed performance thresholds.

## Integration resolution

The Git output defect was corrected and tested for zero, one and multiple rows; see pipeline-probes.log. The harmless persistence audit is included as reviewed source documentation. Final execution evidence is maintained in ../../V0207_FINALIZATION_REPORT.md. This static review did not execute those checks.

## Victory capture diagnosis and harness correction

The three fresh `after-test-repair/ui0204-victory-*` images show a partially transparent outcome paper, including the portrait `618x1400` capture. This is supported by the capture timing: `Ui0204Checks` calls `ShowVictory` directly and waits five process frames plus five inside `Capture`. `Game.FastChecks` does not set `VictoryScreen.InstantAnimations` for this direct call. The production reveal needs 0.65 seconds for its shade and starts its paper fade 0.12 seconds later, reaching full paper opacity after 0.77 seconds; rolling motion lasts 0.34 seconds. A small fixed frame count can therefore capture the intended reveal phase.

The separate fresh `victory.png` waits at least 0.8 seconds and shows opaque readable parchment; `ui0207-outcome.png` explicitly uses instant outcome animation and is also opaque/readable. These observations do not establish a production opacity defect. They also do not prove settled portrait layout: that requires a later settled capture.

With integration approval, `Ui0204Checks` now waits up to five seconds for the actual `VictoryPaper` to stop rolling and reach opacity of at least 0.999 before layout checks/capture. It preserves the normal production reveal and existing layout assertions; it does not accelerate, skip or edit the outcome animation. No rerun was performed by this reviewer.

## Active version metadata correction

The exported title images exposed a stale active footer: `@Ancient_Naval_v0.13 30.09.2026`. No `AppVersion` helper exists in the frozen source; the authoritative current value is `project.godot`'s `application/config/version` (`v020.7`). With integration approval, the single `StartScreen` footer line now interpolates that project setting and omits the stale date. GitHub branding, typography, tint and placement remain unchanged. This corrects version identification without changing mechanics, art, saved state or introducing a later-version feature. The final build/export and current footer captures remain the integrating agent's responsibility.

The current release report must distinguish historical supplied performance passes from any failed or pending fresh gate. Other applications were reported as competing for the GPU during the fresh failure; this review did not measure or establish causation and did not launch/stop any application. Documentation must not present an unpassed fresh gate as verified final performance.
