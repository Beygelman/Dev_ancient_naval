using System;
using System.Collections.Generic;
using System.Linq;
using DevAncientNaval.Core.Battle;
using Godot;
using Side = DevAncientNaval.Core.Units.Side;

namespace DevAncientNaval.Presentation.Map;
public partial class BoardView
{
    internal int TownInterfaceDrawCount { get; private set; }
    private readonly Dictionary<int, AmphoraHealthAnimation> _townHealth = new();
    private readonly ulong _townAnimationEpoch = Time.GetTicksMsec();
    private float TownAnimationTime => (Time.GetTicksMsec() - _townAnimationEpoch) / 1000f;
    internal static Vector2 TownHealthAnchor(Vector2 center) => center + new Vector2(38, -31);

    private readonly Dictionary<int, (Vector2 Position, float Height, float Width)[]> _townHomes = new();
    internal static Vector2[] TownMills(Village town) => town.Level < 2 ? Array.Empty<Vector2>() : town.Level < 4 ? new[]
    {
        new Vector2(-24, -17)
    }

    : new[]
    {
        new Vector2(-29, -18),
        new Vector2(26, -8)
    };
    private void DrawVillage(Node2D canvas, Village town, Vector2 center)
    {
        if (!_townHomes.TryGetValue(town.Id, out var homes))
        {
            var random = new Random(Board.Seed ^ town.Id * 719);
            homes = Enumerable.Range(0, 16).Select(i => (new Vector2((float)random.NextDouble() * 42 - 21, (float)random.NextDouble() * 22 - 13), 10f + random.Next(13), 5f + random.Next(4))).OrderBy(h => h.Item1.Y).ToArray();
            _townHomes[town.Id] = homes;
        }

        var accent = FleetPalette.For(Battle, town.Owner);
        var ground = new[]
        {
            center + new Vector2(-30, -9),
            center + new Vector2(0, -23),
            center + new Vector2(33, -4),
            center + new Vector2(2, 17)
        };
        canvas.DrawColoredPolygon(ground, new Color("999b7a"));
        // Wheat lies between the settlement and its protective front wall.
        if (town.Level >= 2)
        {
            int rows = town.Level >= 4 ? 5 : 3;
            for (int field = 0; field < rows; field++)
            {
                var at = center + new Vector2(-30 + field * 11, 11 + field % 2 * 3);
                canvas.DrawColoredPolygon(new[] { at, at + new Vector2(10, -5), at + new Vector2(18, 0), at + new Vector2(8, 5) }, new Color("c5b06c"));
                for (int stalk = 0; stalk < 4; stalk++)
                    canvas.DrawLine(at + new Vector2(3 + stalk * 3, 1), at + new Vector2(3 + stalk * 3, -3), new Color("ead499"), 1);
            }
        }

        int count = 2 + town.Level * 2;
        for (int i = 0; i < count; i++)
        {
            var home = homes[i];
            var p = center + home.Position;
            float h = home.Height + Math.Max(0, town.Level - 2) * 4;
            float w = home.Width;
            canvas.DrawColoredPolygon(new[] { p + new Vector2(-w, 0), p + new Vector2(2, 4), p + new Vector2(2, 4 - h), p + new Vector2(-w, -h) }, new Color("e2caa1").Darkened(i % 4 * .035f));
            canvas.DrawColoredPolygon(new[] { p + new Vector2(2, 4), p + new Vector2(w + 3, 0), p + new Vector2(w + 3, -h), p + new Vector2(2, 4 - h) }, new Color("ac9a77"));
            canvas.DrawColoredPolygon(new[] { p + new Vector2(-w - 1, -h), p + new Vector2(0, -h - 5), p + new Vector2(w + 4, -h), p + new Vector2(2, 5 - h) }, accent.Darkened(.25f));
            for (int window = 0; window < (town.Level >= 3 ? 2 : 1); window++)
                canvas.DrawRect(new Rect2(p + new Vector2(-w + 2, -h + 5 + window * 7), new Vector2(2, 3)), new Color("655b4a"));
        }

        foreach (var mill in TownMills(town))
        {
            var p = center + mill;
            canvas.DrawColoredPolygon(new[] { p + new Vector2(-5, 9), p + new Vector2(6, 9), p + new Vector2(4, -7), p + new Vector2(-3, -7) }, new Color("d6c6a3"));
            canvas.DrawColoredPolygon(new[] { p + new Vector2(-6, -7), p + new Vector2(0, -12), p + new Vector2(6, -7) }, new Color("886d4c"));
        }

        if (town.IsFortified)
        {
            var wall = new[]
            {
                center + new Vector2(-35, -8),
                center + new Vector2(-35, 10),
                center + new Vector2(0, 28),
                center + new Vector2(36, 10),
                center + new Vector2(36, -9)
            };
            bool stone = town.Level >= 3;
            if (stone)
                for (int segment = 1; segment < wall.Length; segment++)
                    canvas.DrawColoredPolygon(new[] { wall[segment - 1], wall[segment], wall[segment] + new Vector2(0, -6), wall[segment - 1] + new Vector2(0, -6) }, new Color("a6ab99"));
            else
                canvas.DrawPolyline(wall, new Color("826442"), 4, true);
            for (int i = 1; i < wall.Length; i++)
                for (float t = 0; t <= 1; t += .14f)
                {
                    var at = wall[i - 1].Lerp(wall[i], t);
                    if (stone)
                        canvas.DrawRect(new Rect2(at + new Vector2(-2, -8), new Vector2(4, 5)), new Color("d1cbb6"));
                    else
                        canvas.DrawLine(at, at + new Vector2(0, -7), new Color("b49a6b"), 2, true);
                }
        }

        if (town.HasPort)
            DrawPort(canvas, town, center);
        if (town.Owner is not null)
            canvas.DrawLine(center + new Vector2(13, -24), center + new Vector2(13, -47), new Color("eadfc2"), 2, true);
    }

    private void DrawPort(Node2D canvas, Village town, Vector2 center)
    {
        var sea = Projection.GridToWorld(Battle.PortBerth(town)) - Projection.GridToWorld(town.Position);
        var axis = sea.Normalized();
        var side = axis.Orthogonal();
        for (int pier = -1; pier <= 1; pier++)
        {
            var at = center + side * pier * 10 + axis * 15;
            var end = at + axis * (18 + (pier == 0 ? 7 : 0));
            canvas.DrawLine(at + new Vector2(2, 3), end + new Vector2(2, 3), new Color("435e60"), 7);
            canvas.DrawLine(at, end, new Color("b9a57c"), 5, true);
            for (int plank = 0; plank < 5; plank++)
            {
                var p = at.Lerp(end, plank / 4f);
                canvas.DrawLine(p - side * 3, p + side * 3, new Color("73664d"), 1);
            }

            var boat = end + side * 6;
            canvas.DrawColoredPolygon(new[] { boat - axis * 5, boat + side * 2, boat + axis * 5, boat - side * 2 }, new Color("735c41"));
            canvas.DrawLine(boat, boat + new Vector2(0, -6), new Color("ece0b3"), 1);
        }

        canvas.DrawRect(new Rect2(center + axis * 20 - new Vector2(4, 9), new Vector2(8, 7)), new Color("d5c098"));
    }

    private void DrawVillageInterface(Node2D canvas, Village town)
    {
        TownInterfaceDrawCount++;
        var accent = FleetPalette.For(Battle, town.Owner);
        float width = ThemeDB.FallbackFont.GetStringSize(town.Name, fontSize: 13).X;
        canvas.DrawString(ThemeDB.FallbackFont, new Vector2(-width * .5f, 37), town.Name, fontSize: 13, modulate: Colors.Black);
        for (int i = 0; i < 5; i++)
            canvas.DrawRect(new Rect2(new Vector2(-18 + i * 8, 41), new Vector2(5, 4)), i < town.Level ? accent : new Color("475857"));
        if (!_townHealth.TryGetValue(town.Id, out var animation))
            _townHealth[town.Id] = animation = new AmphoraHealthAnimation();
        float time = TownAnimationTime;
        animation.Observe(town.Health, town.MaxHealth, time);
        AmphoraBadgeArt.Draw(canvas, new Vector2(38, -35), town.Health, town.MaxHealth, accent, null, animation.Motion(time));
        if (Battle.CanCaptureVillage(Side.Player, town.Id))
        {
            var flag = new Vector2(-32, -39);
            canvas.DrawCircle(flag, 16, new Color(1, .85f, .45f, .2f));
            canvas.DrawArc(flag, 15, 0, Mathf.Tau, 28, new Color("ffe29a"), 2, true);
            canvas.DrawLine(flag + new Vector2(-6, 12), flag + new Vector2(-6, -8), new Color("eadfc2"), 2, true);
            canvas.DrawColoredPolygon(new[] { flag + new Vector2(-5, -8), flag + new Vector2(10, -5), flag + new Vector2(-5, 2) }, new Color("ffe29a"));
        }
    }
}
