using System;
using Godot;

namespace DevAncientNaval.Presentation.Map;

public partial class FleetView
{
    private void DrawBalloonEnvelope(Vector2 center, Color color)
    {
        Ink.DrawCircle(center, 20, color.Darkened(.3f));
        // Curved colored gores form one volume rather than a flat circular marker.
        for (int strip = 0; strip < 7; strip++)
        {
            float left = -1 + strip * 2f / 7;
            float right = -1 + (strip + 1) * 2f / 7;
            var panel = new Vector2[18];
            for (int row = 0; row < 9; row++)
            {
                float t = row * Mathf.Pi / 8;
                float width = MathF.Sin(t) * 20;
                float y = -MathF.Cos(t) * 20;
                panel[row] = center + new Vector2(left * width, y);
                panel[17 - row] = center + new Vector2(right * width, y);
            }
            DrawProjectedPolygon(panel, color.Lightened(strip is 1 or 2 ? .15f : 0).Darkened(MathF.Abs(strip - 2) * .045f));
        }
        Ink.DrawArc(center + new Vector2(-3, -3), 13, -2.5f, -1.25f, 16, new Color(1, .96f, .78f, .5f), 1.4f, true);
        Ink.DrawRect(new Rect2(center + new Vector2(-4, 18), new Vector2(8, 3)), color.Darkened(.25f));
    }
}
