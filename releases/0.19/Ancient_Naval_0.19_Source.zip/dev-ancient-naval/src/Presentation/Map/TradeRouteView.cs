using Godot;
using Side = DevAncientNaval.Core.Units.Side;

namespace DevAncientNaval.Presentation.Map;
public partial class BoardView
{
    private readonly SeaGeometryBatch _tradeInk = new();
    private void DrawTradeRoutes(Node2D canvas, Rect2 bounds)
    {
        _tradeInk.Clear();
        var color = new Color(FleetPalette.For(Battle, Side.Player), .28f);
        foreach (var route in Battle.TradeRoutes(Side.Player).Routes)
        {
            float distance = 0;
            for (int i = 1; i < route.Count; i++)
            {
                var a = Projection.GridToWorld(route[i - 1]);
                var b = Projection.GridToWorld(route[i]);
                float length = a.DistanceTo(b);
                bool known = Battle.Vision.IsExplored(Side.Player, route[i - 1]) && Battle.Vision.IsExplored(Side.Player, route[i]);
                if (known)
                    for (float at = 0; at < length; at += 2)
                        if ((distance + at) % 14 < 7)
                            _tradeInk.Line(a.Lerp(b, at / length), a.Lerp(b, System.Math.Min(length, at + 2) / length), color);
                distance += length;
            }
        }

        _tradeInk.Submit(canvas, 1.5f);
    }
}
