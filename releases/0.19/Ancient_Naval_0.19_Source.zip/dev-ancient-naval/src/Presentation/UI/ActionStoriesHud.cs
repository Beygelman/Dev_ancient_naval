using System.Threading.Tasks;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Core.Units;
using Godot;
using Side = DevAncientNaval.Core.Units.Side;

namespace DevAncientNaval.Presentation.UI;
public partial class DebugHud
{
    private ActionPapyrus _claimPapyrus = null!, _treasuryPapyrus = null!;
    internal ActionPapyrus ClaimPapyrus => _claimPapyrus;
    internal ActionPapyrus TreasuryPapyrus => _treasuryPapyrus;
    private void BuildActionStories()
    {
        _claimPapyrus = new ActionPapyrus
        {
            Name = "HarborClaimPapyrus", ArtworkPath = "res://assets/ui/harbor-claim-0.19.png",
            TooltipText = "Claim this harbor"
        };
        _treasuryPapyrus = new ActionPapyrus
        {
            Name = "TreasuryAwakeningPapyrus", ArtworkPath = "res://assets/ui/treasury-awakening-0.19.png",
            TooltipText = "Awaken the sunken treasury"
        };
        _root.AddChild(_claimPapyrus);
        _root.AddChild(_treasuryPapyrus);
        _claimPapyrus.Pressed += () => CaptureRequested?.Invoke();
        _treasuryPapyrus.Pressed += () => LootRequested?.Invoke();
    }
    private void UpdateActionStories(BattleState battle, Ship? ship, Village? village, bool canAct)
    {
        _claimPapyrus.SetReady(canAct && village is not null && battle.CanCaptureVillage(Side.Player, village.Id));
        _treasuryPapyrus.SetReady(canAct && ship is { Owner: Side.Player } && battle.CanLootTreasury(Side.Player, ship.Id));
    }
    internal Task ConsumeStory(bool capture) => (capture ? _claimPapyrus : _treasuryPapyrus).ConsumeAsync();
    private void PositionSideActions()
    {
        var viewport = GetViewport().GetVisibleRect().Size;
        float left = _shipCard.Visible ? _shipCard.Position.X + _shipCard.Size.X + 14 : 18;
        left = Mathf.Min(left, Mathf.Max(18, viewport.X - 360));
        // A bottom-anchored fan beside the ledger, unchanged by map panning.
        var position = new Vector2(left, viewport.Y - 170);
        _radial.Position = position;
        _resourceRoot.Position = position;
        var storyPosition = new Vector2(left, Mathf.Max(90, position.Y - 130));
        _claimPapyrus.Position = storyPosition;
        _treasuryPapyrus.Position = storyPosition;
    }
}

