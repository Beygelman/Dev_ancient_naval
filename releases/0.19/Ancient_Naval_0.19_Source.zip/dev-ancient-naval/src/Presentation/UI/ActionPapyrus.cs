using System;
using System.Threading.Tasks;
using Godot;

namespace DevAncientNaval.Presentation.UI;

/// <summary>A revealed pictorial action. Its roll-and-burn is cosmetic; Main commits afterwards.</summary>
public partial class ActionPapyrus : Control
{
    private Control _clip = null!;
    private TextureRect _ink = null!;
    private float _age, _consumeAge;
    private bool _hovered;
    private TaskCompletionSource? _completion;
    public string ArtworkPath { get; set; } = "";
    public bool IsConsuming => _completion is not null;
    public float ConsumptionProgress { get; private set; }
    public event Action? Pressed;
    public override void _Ready()
    {
        Size = new(344, 122);
        MouseFilter = MouseFilterEnum.Stop;
        _clip = new Control { ClipContents = true, MouseFilter = MouseFilterEnum.Ignore };
        AddChild(_clip);
        _ink = new TextureRect
        {
            Texture = GD.Load<Texture2D>(ArtworkPath),
            ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
            StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
            MouseFilter = MouseFilterEnum.Ignore
        };
        _clip.AddChild(_ink);
        MouseEntered += () => { _hovered = true; QueueRedraw(); };
        MouseExited += () => { _hovered = false; QueueRedraw(); };
        Hide();
        SetProcess(false);
    }
    public void SetReady(bool ready)
    {
        if (IsConsuming) return;
        if (!ready) { Hide(); SetProcess(false); return; }
        if (Visible) return;
        _age = 0;
        ConsumptionProgress = 0;
        Show();
        SetProcess(true);
    }
    public Task ConsumeAsync()
    {
        if (_completion is not null) return _completion.Task;
        _completion = new TaskCompletionSource();
        _age = 1;
        _consumeAge = 0;
        ConsumptionProgress = 0;
        Show();
        SetProcess(true);
        return _completion.Task;
    }
    public override void _GuiInput(InputEvent input)
    {
        if (!IsConsuming && input is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true })
        {
            AcceptEvent();
            Pressed?.Invoke();
        }
    }
    public override void _Process(double delta)
    {
        if (IsConsuming)
        {
            _consumeAge += (float)delta;
            ConsumptionProgress = Math.Clamp(_consumeAge / .85f, 0, 1);
        }
        else _age = Math.Min(1, _age + (float)delta / .32f);
        float reveal = 1 - Mathf.Pow(1 - _age, 3);
        float roll = IsConsuming ? 1 - Mathf.SmoothStep(0, .65f, ConsumptionProgress) : 1;
        float width = (Size.X - 16) * reveal;
        float height = (Size.Y - 16) * roll;
        _clip.Position = new((Size.X - width) * .5f, 8);
        _clip.Size = new(width, height);
        _ink.Position = new((width - (Size.X - 30)) * .5f, 3);
        _ink.Size = new(Size.X - 30, Size.Y - 26);
        _ink.Modulate = new Color(1, 1, 1, roll);
        QueueRedraw();
        if (IsConsuming && ConsumptionProgress >= 1)
        {
            var completed = _completion;
            _completion = null;
            Hide();
            SetProcess(false);
            completed!.TrySetResult();
        }
        else if (!IsConsuming && _age >= 1) SetProcess(false);
    }
    public override void _Draw()
    {
        float reveal = 1 - Mathf.Pow(1 - _age, 3);
        float roll = IsConsuming ? 1 - Mathf.SmoothStep(0, .65f, ConsumptionProgress) : 1;
        float width = (Size.X - 16) * reveal;
        float height = (Size.Y - 16) * roll;
        var origin = new Vector2((Size.X - width) * .5f, 8);
        var paper = PapyrusStyle.Paper.Lightened(_hovered && !IsConsuming ? .1f : 0);
        if (height > 1)
        {
            DrawStyleBox(PapyrusStyle.Panel(), new Rect2(origin + new Vector2(0, 3), new(width, height)));
            DrawRect(new Rect2(origin, new(width, height)), new Color(paper, .98f));
            for (int row = 0; row < 8; row++)
                DrawLine(origin + new Vector2(4, height * row / 8), origin + new Vector2(width - 4, height * row / 8 + 1), new Color(PapyrusStyle.FaintInk, .055f), 1);
        }
        float burn = IsConsuming ? Mathf.SmoothStep(.45f, .8f, ConsumptionProgress) : 0;
        var edge = paper.Darkened(burn * .9f);
        DrawLine(origin + new Vector2(-3, height), origin + new Vector2(width + 3, height), new Color(edge, 1 - burn), 7, true);
        DrawLine(origin + new Vector2(-3, height - 2), origin + new Vector2(width + 3, height - 2), new Color(PapyrusStyle.Bronze, 1 - burn), 1, true);
        if (burn > 0)
            for (int spark = 0; spark < 22; spark++)
            {
                float x = 8 + (Size.X - 16) * spark / 21;
                float phase = spark * 2.37f;
                var point = new Vector2(x + Mathf.Sin(phase) * burn * 12, 13 - burn * (9 + spark % 5 * 7));
                DrawCircle(point, 1.2f + spark % 3 * .35f, new Color(1, .52f + spark % 3 * .1f, .14f, (1 - ConsumptionProgress) * 1.2f));
            }
    }
    public override void _ExitTree() => _completion?.TrySetCanceled();
}
