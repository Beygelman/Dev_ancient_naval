using System;
using System.Threading.Tasks;
using DevAncientNaval.Core.Battle;
using DevAncientNaval.Core.Units;

namespace DevAncientNaval.Presentation;
public partial class Main
{
    public async Task CaptureVillage()
    {
        if (!CanCommand || SelectedVillageId is not { } id || !Battle.CanCaptureVillage(Side.Player, id)) return;
        await CommitAfterStory(() => Battle.CanCaptureVillage(Side.Player, id), b => b.CaptureVillage(Side.Player, id), true);
    }
    public async Task LootTreasury()
    {
        if (!CanCommand || SelectedShipId is not { } id || !Battle.CanLootTreasury(Side.Player, id)) return;
        await CommitAfterStory(() => Battle.CanLootTreasury(Side.Player, id), b => b.LootTreasury(Side.Player, id), false);
    }
    private async Task CommitAfterStory(Func<bool> stillReady, Func<BattleState, CommandResult> command, bool capture)
    {
        var battle = Battle;
        Busy = true;
        try
        {
            // Begin before refreshing: the busy HUD retains the consuming banner.
            Task animation = FastChecks ? Task.CompletedTask : Hud.ConsumeStory(capture);
            MapInput.CancelGesture();
            Refresh();
            await animation;
        }
        finally { Busy = false; }
        if (ReferenceEquals(battle, Battle) && stillReady())
            await Perform(command, deferImpacts: !capture);
        else Refresh();
    }
}
